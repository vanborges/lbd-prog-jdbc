create function loop_select() returns void
    language plpgsql
as
$$
DECLARE registro RECORD;
BEGIN 
	FOR registro IN  SELECT * FROM funcionario LOOP 
		RAISE NOTICE 'Valores: %, %, %, %, %, %', registro.pnome, registro.cpf, registro.sexo, registro.salario, registro.cpf_supervisor, registro.dnr; 
	END LOOP;
END;
$$;

alter function loop_select() owner to postgres;

