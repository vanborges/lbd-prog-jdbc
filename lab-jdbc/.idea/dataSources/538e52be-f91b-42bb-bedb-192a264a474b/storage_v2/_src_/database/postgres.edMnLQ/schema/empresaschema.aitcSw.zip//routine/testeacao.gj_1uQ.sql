create function testeacao() returns trigger
    language plpgsql
as
$$
BEGIN
IF TG_OP='INSERT' THEN
ELSIF TG_OP='DELETE' THEN
ELSIF TG_OP='UPDATE' THEN
END IF;
RETURN NEW;
END;
$$;

alter function testeacao() owner to postgres;

