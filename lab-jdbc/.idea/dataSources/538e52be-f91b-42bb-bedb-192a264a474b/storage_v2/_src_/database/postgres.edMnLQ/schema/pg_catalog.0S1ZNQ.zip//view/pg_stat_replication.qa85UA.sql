create view pg_stat_replication(pid, usesysid, usename, application_name, client_addr, client_hostname, client_port,
                                backend_start, backend_xmin, state, sent_location, write_location, flush_location,
                                replay_location, sync_priority, sync_state) as
SELECT s.pid,
       s.usesysid,
       u.rolname AS usename,
       s.application_name,
       s.client_addr,
       s.client_hostname,
       s.client_port,
       s.backend_start,
       s.backend_xmin,
       w.state,
       w.sent_location,
       w.write_location,
       w.flush_location,
       w.replay_location,
       w.sync_priority,
       w.sync_state
FROM pg_stat_get_activity(NULL::integer) s(datid, pid, usesysid, application_name, state, query, wait_event_type,
                                           wait_event, xact_start, query_start, backend_start, state_change,
                                           client_addr, client_hostname, client_port, backend_xid, backend_xmin, ssl,
                                           sslversion, sslcipher, sslbits, sslcompression, sslclientdn),
     pg_authid u,
     pg_stat_get_wal_senders() w(pid, state, sent_location, write_location, flush_location, replay_location,
                                 sync_priority, sync_state)
WHERE ((s.usesysid = u.oid) AND (s.pid = w.pid));

alter table pg_stat_replication
    owner to postgres;

