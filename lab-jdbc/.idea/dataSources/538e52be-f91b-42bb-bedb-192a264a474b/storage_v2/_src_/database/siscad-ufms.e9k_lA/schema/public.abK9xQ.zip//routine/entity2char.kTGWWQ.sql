create function entity2char(t text) returns text
    immutable
    language plpgsql
as
$$
declare
	r record;
begin
	for r in
	select distinct ce.ch, ce.name
	from
		character_entity ce
		inner join (
								 select name[1] "name"
								 from regexp_matches(t, '&([A-Za-z]+?);', 'g') r(name)
							 ) s on ce.name = s.name
	loop
		t := replace(t, '&' || r.name || ';', r.ch);
	end loop;

	for r in
	select distinct
		hex[1] hex,
		('x' || repeat('0', 8 - length(hex[1])) || hex[1])::bit(32)::int codepoint
	from regexp_matches(t, '&#x([0-9a-f]{1,8}?);', 'gi') s(hex)
	loop
		t := regexp_replace(t, '&#x' || r.hex || ';', chr(r.codepoint), 'gi');
	end loop;

	for r in
	select distinct
		chr(codepoint[1]::int) ch,
		codepoint[1] codepoint
	from regexp_matches(t, '&#([0-9]{1,10}?);', 'g') s(codepoint)
	loop
		t := replace(t, '&#' || r.codepoint || ';', r.ch);
	end loop;

	return t;
end;
$$;

alter function entity2char(text) owner to postgres;

