create view "ViewAcademicoCurso"("ViewAcademicoCursoId", "ViewAcademicoCursoCentroId", "ViewAcademicoCursoCursoCodigo",
                                 "ViewAcademicoCursoCursoNome", "ViewAcademicoCursoAcademicoRga",
                                 "ViewAcademicoCursoAcademicoNome", "ViewAcademicoCursoAcademicoSituacao",
                                 "ViewAcademicoCursoTipoSituacaoNome", "ViewAcademicoCursoAcademicoCpf",
                                 "ViewAcademicoCursoAcademicoRg", "ViewAcademicoCursoAcademicoDtNasc") as
    (SELECT DISTINCT a."academicoId"                         AS "ViewAcademicoCursoId",
                     ce."centroId"                           AS "ViewAcademicoCursoCentroId",
                     c."cursoCodigo"                         AS "ViewAcademicoCursoCursoCodigo",
                     c."cursoNome"                           AS "ViewAcademicoCursoCursoNome",
                     a."academicoRga"                        AS "ViewAcademicoCursoAcademicoRga",
                     a."academicoNome"                       AS "ViewAcademicoCursoAcademicoNome",
                     a."academicoSituacao"                   AS "ViewAcademicoCursoAcademicoSituacao",
                     ((((((ts."tipoSituacaoNome")::text || ' ('::text) || o."ocorrenciaAno") || '/'::text) ||
                       o."ocorrenciaSemestre") || ')'::text) AS "ViewAcademicoCursoTipoSituacaoNome",
                     a."academicoCpf"                        AS "ViewAcademicoCursoAcademicoCpf",
                     a."academicoNumRg"                      AS "ViewAcademicoCursoAcademicoRg",
                     a."academicoDtNasc"                     AS "ViewAcademicoCursoAcademicoDtNasc"
     FROM ((((academico a
         JOIN curso c ON ((a."cursoId" = c."cursoId")))
         JOIN ocorrencia o ON ((o."academicoId" = a."academicoId")))
         JOIN "tipoSituacao" ts ON ((o."tipoSituacaoId" = ts."tipoSituacaoId")))
              JOIN centro ce ON ((c."centroId" = ce."centroId")))
     WHERE ((c."cursoCodigo" <> '9999'::bpchar) AND (c."cursoCodigo" <> '5555'::bpchar) AND
            ((a."academicoId", o."ocorrenciaSequencia") IN (SELECT o_1."academicoId",
                                                                   max(o_1."ocorrenciaSequencia") AS max
                                                            FROM ocorrencia o_1
                                                            GROUP BY o_1."academicoId")))
     ORDER BY a."academicoId", ce."centroId", c."cursoCodigo", c."cursoNome", a."academicoRga", a."academicoNome",
              a."academicoSituacao",
              ((((((ts."tipoSituacaoNome")::text || ' ('::text) || o."ocorrenciaAno") || '/'::text) ||
                o."ocorrenciaSemestre") || ')'::text), a."academicoCpf", a."academicoNumRg", a."academicoDtNasc")
    UNION ALL
    (SELECT DISTINCT a."academicoId"                         AS "ViewAcademicoCursoId",
                     ce."centroId"                           AS "ViewAcademicoCursoCentroId",
                     c."cursoCodigo"                         AS "ViewAcademicoCursoCursoCodigo",
                     c."cursoNome"                           AS "ViewAcademicoCursoCursoNome",
                     a."academicoRga"                        AS "ViewAcademicoCursoAcademicoRga",
                     a."academicoNome"                       AS "ViewAcademicoCursoAcademicoNome",
                     a."academicoSituacao"                   AS "ViewAcademicoCursoAcademicoSituacao",
                     ((((((ts."tipoSituacaoNome")::text || ' ('::text) || o."ocorrenciaAno") || '/'::text) ||
                       o."ocorrenciaSemestre") || ')'::text) AS "ViewAcademicoCursoTipoSituacaoNome",
                     a."academicoCpf"                        AS "ViewAcademicoCursoAcademicoCpf",
                     a."academicoNumRg"                      AS "ViewAcademicoCursoAcademicoRg",
                     a."academicoDtNasc"                     AS "ViewAcademicoCursoAcademicoDtNasc"
     FROM ((((academico a
         JOIN curso c ON ((a."cursoId" = c."cursoId")))
         JOIN centro ce ON ((a."centroId" = ce."centroId")))
         JOIN ocorrencia o ON ((o."academicoId" = a."academicoId")))
              JOIN "tipoSituacao" ts ON ((o."tipoSituacaoId" = ts."tipoSituacaoId")))
     WHERE (((c."cursoCodigo" = '9999'::bpchar) OR (c."cursoCodigo" = '5555'::bpchar)) AND
            ((a."academicoId", o."ocorrenciaSequencia") IN (SELECT o_1."academicoId",
                                                                   max(o_1."ocorrenciaSequencia") AS max
                                                            FROM ocorrencia o_1
                                                            GROUP BY o_1."academicoId")))
     ORDER BY a."academicoId", ce."centroId", c."cursoCodigo", c."cursoNome", a."academicoRga", a."academicoNome",
              a."academicoSituacao",
              ((((((ts."tipoSituacaoNome")::text || ' ('::text) || o."ocorrenciaAno") || '/'::text) ||
                o."ocorrenciaSemestre") || ')'::text), a."academicoCpf", a."academicoNumRg", a."academicoDtNasc");

alter table "ViewAcademicoCurso"
    owner to postgres;

