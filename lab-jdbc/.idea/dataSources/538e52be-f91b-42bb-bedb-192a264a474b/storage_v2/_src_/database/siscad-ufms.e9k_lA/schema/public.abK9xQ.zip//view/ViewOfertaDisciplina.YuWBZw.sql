create view "ViewOfertaDisciplina"("ViewOfertaDisciplinaOfertaAno", "ViewOfertaDisciplinaOfertaSemestre",
                                   "ViewOfertaDisciplinaOfertaPeriodoEspecial", "ViewOfertaDisciplinaDepartamentoId",
                                   "ViewOfertaDisciplinaDepartamentoSigla", "ViewOfertaDisciplinaDepartamentoNome",
                                   "ViewOfertaDisciplinaDisciplinaId", "ViewOfertaDisciplinaDisciplinaCodigo",
                                   "ViewOfertaDisciplinaDisciplinaNome", "ViewOfertaDisciplinaDisciplinaCarga",
                                   "ViewOfertaDisciplinaCursoCodigo", "ViewOfertaDisciplinaCursoNome",
                                   "ViewOfertaDisciplinaId", "ViewOfertaDisciplinaCursoModalidadeId",
                                   "ViewOfertaDisciplinaCentroId", "ViewOfertaDisciplinaCentroSigla",
                                   "ViewOfertaDisciplinaCentroNome", "ViewOfertaDisciplinaPoloId",
                                   "ViewOfertaDisciplinaPoloNome") as
SELECT oferta."ofertaAno"               AS "ViewOfertaDisciplinaOfertaAno",
       oferta."ofertaSemestre"          AS "ViewOfertaDisciplinaOfertaSemestre",
       oferta."ofertaPeriodoEspecial"   AS "ViewOfertaDisciplinaOfertaPeriodoEspecial",
       departamento."departamentoId"    AS "ViewOfertaDisciplinaDepartamentoId",
       departamento."departamentoSigla" AS "ViewOfertaDisciplinaDepartamentoSigla",
       departamento."departamentoNome"  AS "ViewOfertaDisciplinaDepartamentoNome",
       disciplina."disciplinaId"        AS "ViewOfertaDisciplinaDisciplinaId",
       disciplina."disciplinaCodigo"    AS "ViewOfertaDisciplinaDisciplinaCodigo",
       disciplina."disciplinaNome"      AS "ViewOfertaDisciplinaDisciplinaNome",
       disciplina."disciplinaCarga"     AS "ViewOfertaDisciplinaDisciplinaCarga",
       curso."cursoCodigo"              AS "ViewOfertaDisciplinaCursoCodigo",
       curso."cursoNome"                AS "ViewOfertaDisciplinaCursoNome",
       oferta."ofertaId"                AS "ViewOfertaDisciplinaId",
       curso."modalidadeId"             AS "ViewOfertaDisciplinaCursoModalidadeId",
       centro."centroId"                AS "ViewOfertaDisciplinaCentroId",
       centro."centroSigla"             AS "ViewOfertaDisciplinaCentroSigla",
       centro."centroNome"              AS "ViewOfertaDisciplinaCentroNome",
       polo."poloId"                    AS "ViewOfertaDisciplinaPoloId",
       polo."poloNome"                  AS "ViewOfertaDisciplinaPoloNome"
FROM ((((((((((oferta
    JOIN grade ON ((grade."gradeId" = oferta."gradeId")))
    JOIN curso ON ((curso."cursoId" = grade."cursoId")))
    JOIN disciplina ON ((disciplina."disciplinaId" = grade."disciplinaId")))
    JOIN docente ON ((docente."docenteId" = oferta."docenteId")))
    JOIN departamento ON ((departamento."departamentoId" = disciplina."departamentoId")))
    JOIN centro ON ((centro."centroId" = departamento."centroId")))
    LEFT JOIN turma ON ((turma."ofertaId" = oferta."ofertaId")))
    LEFT JOIN "cursoTurma" ON (("cursoTurma"."turmaId" = turma."turmaId")))
    LEFT JOIN "cursoPolo" ON (("cursoPolo"."cursoPoloId" = "cursoTurma"."cursoPoloId")))
         LEFT JOIN polo ON ((polo."poloId" = "cursoPolo"."poloId")));

alter table "ViewOfertaDisciplina"
    owner to postgres;

