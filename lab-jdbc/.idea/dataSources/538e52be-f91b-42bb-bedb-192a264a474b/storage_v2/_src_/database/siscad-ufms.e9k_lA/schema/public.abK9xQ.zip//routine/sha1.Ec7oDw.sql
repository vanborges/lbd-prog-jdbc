create function sha1(text) returns text
    immutable
    strict
    language sql
as
$$
SELECT encode(digest($1, 'sha1'), 'hex')
$$;

alter function sha1(text) owner to postgres;

