create function turma_matricula2011() returns trigger
    language plpgsql
as
$$
DECLARE total INTEGER;
BEGIN
  	
    --IF (TG_OP = 'DELETE') THEN
    	
                
        select count(*) INTO total
        from "matriculaAcademicoTurma" t2
        WHERE
        (t2."turmaIdAcademico" = OLD."turmaId" OR
        t2."turmaIdSistema" = OLD."turmaId" OR
        t2."turmaIdCoordenador" = OLD."turmaId");
        
        IF (total > 0) THEN
        	RAISE EXCEPTION 'Há acadêmicos matriculados';
        END IF;
        
    
    RETURN OLD;
    --END IF;      
END;
$$;

alter function turma_matricula2011() owner to postgres;

