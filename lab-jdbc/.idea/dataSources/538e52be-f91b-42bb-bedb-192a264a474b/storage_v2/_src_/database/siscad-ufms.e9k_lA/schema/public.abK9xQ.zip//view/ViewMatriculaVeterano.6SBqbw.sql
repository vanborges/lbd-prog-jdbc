create view "ViewMatriculaVeterano"("ViewMatriculaVeteranoId", "ViewMatriculaVeteranoAcademicoRga",
                                    "ViewMatriculaVeteranoAcademicoNome", "ViewMatriculaVeteranoCursoCodigo",
                                    "ViewMatriculaVeteranoCursoNome", "ViewMatriculaVeteranoCentroId") as
SELECT DISTINCT a."academicoId"   AS "ViewMatriculaVeteranoId",
                a."academicoRga"  AS "ViewMatriculaVeteranoAcademicoRga",
                a."academicoNome" AS "ViewMatriculaVeteranoAcademicoNome",
                c."cursoCodigo"   AS "ViewMatriculaVeteranoCursoCodigo",
                c."cursoNome"     AS "ViewMatriculaVeteranoCursoNome",
                c."centroId"      AS "ViewMatriculaVeteranoCentroId"
FROM (academico a
         JOIN curso c ON ((a."cursoId" = c."cursoId")))
WHERE (a."academicoSituacao" = 'I'::bpchar)
ORDER BY a."academicoId", a."academicoRga", a."academicoNome", c."cursoCodigo", c."cursoNome", c."centroId";

alter table "ViewMatriculaVeterano"
    owner to postgres;

