create function "ofertaUnica"() returns trigger
    language plpgsql
as
$$
DECLARE totalOferta integer;
BEGIN
    /**
    A função e disparada pela trigger na inserção e atualização 
    de um registro na tabela oferta, o objetivo e garantir que so
    exista para cada periodo (ano/semestre/periodo especial) a oferta
    de uma unica disciplina para o curso (independente da sua sequencia).    
    */
  	--
    -- Se for update. 
    --
    IF (TG_OP = 'UPDATE') THEN    	    	  	
        -- se nao mudar o ano/sem/periodoEspecial/grade
    	-- não precisa fazer nada.
        
        raise notice 'total %', NEW."ofertaAno";     
        
        IF NEW."ofertaAno" = OLD."ofertaAno" AND 
           NEW."ofertaSemestre" = OLD."ofertaSemestre" AND
           NEW."ofertaPeriodoEspecial" = OLD."ofertaPeriodoEspecial" AND
           NEW."gradeId" = OLD."gradeId" 
           THEN           
           IF (NEW."ofertaDuracao" = OLD."ofertaDuracao" AND NEW."ofertaAno" < 2011) OR
           NEW."ofertaAno" >= 2011 THEN
			   raise notice 'Não houve alteração';
	           return NEW;
           END IF;
        END IF;   
    	
        -- se não fazer o select para ver se não esta criando uma mesma oferta.
        SELECT count(*) INTO totalOferta
        FROM oferta o JOIN grade g ON o."gradeId" = g."gradeId"              
        WHERE o."ofertaAno" = NEW."ofertaAno" AND
        	  o."ofertaSemestre" = NEW."ofertaSemestre" AND
              o."ofertaPeriodoEspecial" = NEW."ofertaPeriodoEspecial" AND
              ((o."ofertaDuracao"=NEW."ofertaDuracao" AND o."ofertaAno" < 2011) OR
              o."ofertaAno" >= 2011) AND
              (g."cursoId", g."disciplinaId") IN (
                 SELECT cursocodigo."cursoId", grade."disciplinaId" 
                 FROM curso cursocodigo JOIN  curso ON cursocodigo."cursoCodigo" = curso."cursoCodigo"                 
                                        JOIN grade ON curso."cursoId" = grade."cursoId"
                 WHERE grade."gradeId" = NEW."gradeId");
       
        IF totalOferta > 0 THEN
	        RAISE EXCEPTION  'Não pode ter mais de uma oferta para a disciplina de um mesmo curso 
    	    no mesmo período (ano/semestre/período especial)';   
        	return OLD;
         END IF;
         
        return NEW;     
        
	ELSEIF (TG_OP = 'INSERT') THEN
        -- se não fazer o select para ver se não esta criando uma mesma oferta.
        SELECT count(*) INTO totalOferta
        FROM oferta o JOIN grade g ON o."gradeId" = g."gradeId"              
        WHERE o."ofertaAno" = NEW."ofertaAno" AND
        	  o."ofertaSemestre" = NEW."ofertaSemestre" AND
              o."ofertaPeriodoEspecial" = NEW."ofertaPeriodoEspecial" AND
              ((o."ofertaDuracao"=NEW."ofertaDuracao" AND o."ofertaAno" < 2011) OR
              o."ofertaAno" >= 2011) AND
              (g."cursoId", g."disciplinaId") IN (
                 SELECT cursocodigo."cursoId", grade."disciplinaId" 
                 FROM curso cursocodigo JOIN  curso ON cursocodigo."cursoCodigo" = curso."cursoCodigo"                 
                                        JOIN grade ON curso."cursoId" = grade."cursoId"
                 WHERE grade."gradeId" = NEW."gradeId");
       
        IF totalOferta > 0 THEN
	        RAISE EXCEPTION  'Não pode ter mais de uma oferta para a disciplina de um mesmo curso 
    	    no mesmo período (ano/semestre/período especial)';   
        	return OLD;
        END IF;
        
    RETURN NEW;
    END IF;
END;
$$;

alter function "ofertaUnica"() owner to postgres;

