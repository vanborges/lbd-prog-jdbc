create view "ViewAcademicoDisciplina"("ViewAcademicoDisciplinaId", "ViewAcademicoDisciplinaacademicoTurmaId",
                                      "ViewAcademicoDisciplinadisciplinaNome",
                                      "ViewAcademicoDisciplinadisciplinaCodigo",
                                      "ViewAcademicoDisciplinaacademicoTurmaAno",
                                      "ViewAcademicoDisciplinaacademicoTurmaSem",
                                      "ViewAcademicoDisciplinadisciplinaCarga", "foreignId") as
SELECT v."academicoTurmaId" AS "ViewAcademicoDisciplinaId",
       v."academicoTurmaId" AS "ViewAcademicoDisciplinaacademicoTurmaId",
       d."disciplinaNome"   AS "ViewAcademicoDisciplinadisciplinaNome",
       d."disciplinaCodigo" AS "ViewAcademicoDisciplinadisciplinaCodigo",
       v."ANO"              AS "ViewAcademicoDisciplinaacademicoTurmaAno",
       v."SEM"              AS "ViewAcademicoDisciplinaacademicoTurmaSem",
       d."disciplinaCarga"  AS "ViewAcademicoDisciplinadisciplinaCarga",
       v."academicoId"      AS "foreignId"
FROM ("ViewHistorico" v
         JOIN disciplina d ON ((v."disciplinaId" = d."disciplinaId")))
ORDER BY v."ANO", v."SEM", d."disciplinaNome";

alter table "ViewAcademicoDisciplina"
    owner to postgres;

