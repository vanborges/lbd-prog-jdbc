create function "insertAcademicoTurma"() returns trigger
    language plpgsql
as
$$
DECLARE
 /* academicoIsHistorico */
 academicoIsHistorico boolean;
BEGIN
	-- Antes de fazer um insert na tabela academicoTurma
    -- verificar se o historico do academico já não foi
    -- movido para a tabela academicoTurmaHistorico. 
       
    SELECT INTO academicoIsHistorico "isHistoric" 
    FROM  "academico" 
    where "academicoId" = NEW."academicoId";
    
    -- se os dados do academico estiver no historico não permitir adicionar
    -- novos registros na academicoTurma.
    if academicoIsHistorico then

	    RAISE EXCEPTION 'Os dados do academico (academicoId : %), já foram movidos para a 
        tabela academicoTurmaHistorico, portanto não pode ser inserido nenhum registro para o academico na
        tabela "academicoTurma".'
        ,NEW."academicoId";        
        
    end if;    
	return new;
    
END;
$$;

alter function "insertAcademicoTurma"() owner to postgres;

