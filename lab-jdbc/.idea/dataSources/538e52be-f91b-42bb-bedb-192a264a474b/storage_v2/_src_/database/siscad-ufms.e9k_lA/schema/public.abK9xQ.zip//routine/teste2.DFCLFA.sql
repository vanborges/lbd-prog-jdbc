create function teste2(integer) returns text
    language plpgsql
as
$$
DECLARE
cont RECORD;
freq RECORD;
erro TEXT;
flag INTEGER;
BEGIN
erro:='';
flag:=0;

/*for freq in select F.*,D.* from frequencia F,"diaLetivo" D where F."academicoTurmaId"
in (select AT."academicoTurmaId" from "academicoTurma" AT where AT."turmaId"=$1)
and D."diaLetivoId" =F."diaLetivoId" and F."frequenciaValor" is null  and D."diaLetivoCargaHorariaDia" = 0 LOOP
  delete from frequencia where frequencia."academicoTurmaId" = freq."academicoTurmaId";
  erro:=erro||'- DIA LETIVO NULL - DELETADO<br>';
END LOOP;
*/

FOR cont IN select AT."academicoTurmaId",AT."turmaId",AT."academicoTurmaFaltas",AT."academicoTurmaPresenca",AT."academicoTurmaCargaHoraria", AT."academicoTurmaNota",AT."academicoTurmaSituacao"
from "academicoTurma" AT where AT."turmaId" =$1  LOOP
--VERIFICA SE O NUMERO DE FALTAS + NUMERO DE PRESENTA NÃO ESTA BATENDO COM CARGA HORARIO
-- ENTÃO EXECUTA SP TESTE1
if cont."academicoTurmaFaltas"+cont."academicoTurmaPresenca" != cont."academicoTurmaCargaHoraria" then
   if flag=0 then
   execute('select * from teste1('||$1||')');
   flag:=1;
   end if;
   erro:=erro|| '- TESTE1 :'|| $1 ||' - '||cont."academicoTurmaId"||'<br>';

END IF;
--VERIRICA SE ACADEMICO ESTA REPROVADO POR FALTA
if cont."academicoTurmaFaltas" > cont."academicoTurmaCargaHoraria"/4 then
   if cont."academicoTurmaSituacao" ='RF' then
      erro:=erro||'-OK RF : '||cont."academicoTurmaId"||'<br>';
   else
       erro:=erro||'- UPDATE RF : '||cont."academicoTurmaId"||'<br>';
   end if;
else
--SE NÃO ESTA REPROVADO POR FALTA CONFERIR NOTA E SE NECESSARIO ATUALIZAR CAMPO SITUACAO
     if cont."academicoTurmaNota" >= 5 then --APROVADO
        if cont."academicoTurmaSituacao" != 'AP' then
           erro:=erro||'- UPDATE AP :'||cont."academicoTurmaId"||'<br>';
           update "academicoTurma" set "academicoTurmaSituacao" = 'AP' where "academicoTurmaId" =cont."academicoTurmaId";
        else
            erro:=erro||'- OK APROVADO :'||cont."academicoTurmaId"||'<br>';
        end if;
     else --REPROVADO
        if cont."academicoTurmaSituacao" != 'RN' then
           erro:=erro||'- UPDATE RN :'||cont."academicoTurmaId"||'<br>';
           update "academicoTurma" set "academicoTurmaSituacao" = 'RN' where "academicoTurmaId" =cont."academicoTurmaId";
        else
            erro:=erro||'- OK REPROVADO :'||cont."academicoTurmaId"||'<br>';
        end if;
     end if;
end if;

END LOOP;

return erro;

END;
$$;

alter function teste2(integer) owner to postgres;

