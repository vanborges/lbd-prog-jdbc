create view "ViewDiarioEad"("ViewDiarioEadId", "ViewDiarioEaddisciplinaCodigo", "ViewDiarioEaddisciplinaNome",
                            "ViewDiarioEaddisciplinaCarga", "ViewDiarioEadturmaNome", "ViewDiarioEadturmaBloqueio",
                            "foreignId", "ViewDiarioEadofertaDuracao", "ViewDiarioEadofertaId", "ViewDiarioEadAno",
                            "ViewDiarioEadofertaSemestre", "ViewDiarioEadcursoId", "ViewDiarioEadcursoSequencia",
                            "ViewDiarioEadcursoCodigo", "ViewDiarioEadcursoNome", "ViewDiarioEadcentroSigla",
                            "ViewDiarioEadcentroNome", "ViewDiarioEadmodalidadeId") as
    SELECT turma."turmaId"                                          AS "ViewDiarioEadId",
           disciplina."disciplinaCodigo"                            AS "ViewDiarioEaddisciplinaCodigo",
           disciplina."disciplinaNome"                              AS "ViewDiarioEaddisciplinaNome",
           disciplina."disciplinaCarga"                             AS "ViewDiarioEaddisciplinaCarga",
           ((turma."turmaTipo")::text || (turma."turmaNome")::text) AS "ViewDiarioEadturmaNome",
           turma."turmaBloqueio"                                    AS "ViewDiarioEadturmaBloqueio",
           "docenteTurma"."docenteId"                               AS "foreignId",
           oferta."ofertaDuracao"                                   AS "ViewDiarioEadofertaDuracao",
           oferta."ofertaId"                                        AS "ViewDiarioEadofertaId",
           oferta."ofertaAno"                                       AS "ViewDiarioEadAno",
           oferta."ofertaSemestre"                                  AS "ViewDiarioEadofertaSemestre",
           curso."cursoId"                                          AS "ViewDiarioEadcursoId",
           curso."cursoSequencia"                                   AS "ViewDiarioEadcursoSequencia",
           curso."cursoCodigo"                                      AS "ViewDiarioEadcursoCodigo",
           curso."cursoNome"                                        AS "ViewDiarioEadcursoNome",
           centro."centroSigla"                                     AS "ViewDiarioEadcentroSigla",
           centro."centroNome"                                      AS "ViewDiarioEadcentroNome",
           curso."modalidadeId"                                     AS "ViewDiarioEadmodalidadeId"
    FROM ((((((("docenteTurma"
        JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaPai")))
        JOIN (SELECT "cursoTurma"."turmaId",
                     "cursoTurma"."ofertaId"
              FROM "cursoTurma" "cursoTurma"
              GROUP BY "cursoTurma"."turmaId", "cursoTurma"."ofertaId") "ViewCursoTurma" ON (("ViewCursoTurma"."turmaId" = turma."turmaId")))
        JOIN oferta ON (("ViewCursoTurma"."ofertaId" = oferta."ofertaId")))
        JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
        JOIN curso ON ((grade."cursoId" = curso."cursoId")))
        JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
             JOIN centro ON ((disciplina."centroId" = centro."centroId")))
    WHERE (turma."turmaIsFather" IS FALSE)
    UNION
    SELECT turma."turmaId"                                          AS "ViewDiarioEadId",
           disciplina."disciplinaCodigo"                            AS "ViewDiarioEaddisciplinaCodigo",
           disciplina."disciplinaNome"                              AS "ViewDiarioEaddisciplinaNome",
           disciplina."disciplinaCarga"                             AS "ViewDiarioEaddisciplinaCarga",
           ((turma."turmaTipo")::text || (turma."turmaNome")::text) AS "ViewDiarioEadturmaNome",
           turma."turmaBloqueio"                                    AS "ViewDiarioEadturmaBloqueio",
           "docenteTurma"."docenteId"                               AS "foreignId",
           oferta."ofertaDuracao"                                   AS "ViewDiarioEadofertaDuracao",
           oferta."ofertaId"                                        AS "ViewDiarioEadofertaId",
           oferta."ofertaAno"                                       AS "ViewDiarioEadAno",
           oferta."ofertaSemestre"                                  AS "ViewDiarioEadofertaSemestre",
           curso."cursoId"                                          AS "ViewDiarioEadcursoId",
           curso."cursoSequencia"                                   AS "ViewDiarioEadcursoSequencia",
           curso."cursoCodigo"                                      AS "ViewDiarioEadcursoCodigo",
           curso."cursoNome"                                        AS "ViewDiarioEadcursoNome",
           centro."centroSigla"                                     AS "ViewDiarioEadcentroSigla",
           centro."centroNome"                                      AS "ViewDiarioEadcentroNome",
           curso."modalidadeId"                                     AS "ViewDiarioEadmodalidadeId"
    FROM ((((((("docenteTurma"
        JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaId")))
        JOIN (SELECT "cursoTurma"."turmaId",
                     "cursoTurma"."ofertaId"
              FROM "cursoTurma" "cursoTurma"
              GROUP BY "cursoTurma"."turmaId", "cursoTurma"."ofertaId") "ViewCursoTurma" ON (("ViewCursoTurma"."turmaId" = turma."turmaId")))
        JOIN oferta ON (("ViewCursoTurma"."ofertaId" = oferta."ofertaId")))
        JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
        JOIN curso ON ((grade."cursoId" = curso."cursoId")))
        JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
             JOIN centro ON ((disciplina."centroId" = centro."centroId")))
    WHERE (turma."turmaIsFather" IS FALSE);

alter table "ViewDiarioEad"
    owner to postgres;

