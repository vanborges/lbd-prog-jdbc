create view "ViewSIENCurso"(id, codigo, sequencia, nome, email, "anoIni", "anoFim", "anoSemIni", "anoSemFim", situacao,
                            curso_email, centro_id, area, "cursoRecMec", "cursoEnade", "cursoInep",
                            "cursoDataInicioFuncionamento", turno_id, turno, turno_sigla, centro, coordenador,
                            modalidade_id) as
SELECT curso."cursoId"                                             AS id,
       curso."cursoCodigo"                                         AS codigo,
       curso."cursoSequencia"                                      AS sequencia,
       curso."cursoNome"                                           AS nome,
       curso."cursoEmail"                                          AS email,
       curso."cursoAnoIni"                                         AS "anoIni",
       curso."cursoAnoFim"                                         AS "anoFim",
       ((curso."cursoAnoIni" || '/'::text) || curso."cursoSemIni") AS "anoSemIni",
       ((curso."cursoAnoFim" || '/'::text) || curso."cursoSemFim") AS "anoSemFim",
       curso."cursoSituacao"                                       AS situacao,
       curso."cursoEmail"                                          AS curso_email,
       curso."centroId"                                            AS centro_id,
       curso."cursoArea"                                           AS area,
       curso."cursoRecMec",
       curso."cursoEnade",
       curso."cursoInep",
       curso."cursoDataInicioFuncionamento",
       curso."turnoId"                                             AS turno_id,
       turno."turnoDescricao"                                      AS turno,
       turno."turnoSigla"                                          AS turno_sigla,
       centro."centroSigla"                                        AS centro,
       docente."docenteNome"                                       AS coordenador,
       curso."modalidadeId"                                        AS modalidade_id
FROM ((((curso
    LEFT JOIN centro ON ((centro."centroId" = curso."centroId")))
    LEFT JOIN turno ON ((curso."turnoId" = turno."turnoId")))
    LEFT JOIN coordenador ON (((curso."cursoCodigo")::integer = coordenador."_cursoId")))
         LEFT JOIN docente ON ((docente."docenteId" = coordenador."docenteId")))
WHERE ((curso."cursoCodigo", curso."cursoSequencia") IN (SELECT curso_1."cursoCodigo",
                                                                max(curso_1."cursoSequencia") AS max
                                                         FROM curso curso_1
                                                         WHERE ((curso_1."cursoCodigo" <> ''::bpchar) AND
                                                                (curso_1."centroId" <> ALL (ARRAY [2, 99])))
                                                         GROUP BY curso_1."cursoCodigo"));

alter table "ViewSIENCurso"
    owner to postgres;

