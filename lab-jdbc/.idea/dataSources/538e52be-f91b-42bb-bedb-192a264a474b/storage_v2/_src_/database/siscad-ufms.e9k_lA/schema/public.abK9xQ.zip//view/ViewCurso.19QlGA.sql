create view "ViewCurso"("ViewCursoId", "ViewCursoCursoCodigo", "ViewCursoCursoSequencia", "ViewCursoCursoNome",
                        "ViewCursoCursoAnoIni", "ViewCursoCursoAnoFim", "ViewCursoCursoAnoSemIni",
                        "ViewCursoCursoAnoSemFim", "ViewCursoCursoSituacao", "ViewCursoCursoCentroId",
                        "ViewCursoCursoEmail", "ViewCursoModalidadeId", "ViewCursoCursoHoraAula", "cursoId") as
SELECT curso."cursoId"                                                  AS "ViewCursoId",
       curso."cursoCodigo"                                              AS "ViewCursoCursoCodigo",
       to_char((curso."cursoSequencia")::double precision, '000'::text) AS "ViewCursoCursoSequencia",
       curso."cursoNome"                                                AS "ViewCursoCursoNome",
       curso."cursoAnoIni"                                              AS "ViewCursoCursoAnoIni",
       curso."cursoAnoFim"                                              AS "ViewCursoCursoAnoFim",
       ((curso."cursoAnoIni" || '/'::text) || curso."cursoSemIni")      AS "ViewCursoCursoAnoSemIni",
       ((curso."cursoAnoFim" || '/'::text) || curso."cursoSemFim")      AS "ViewCursoCursoAnoSemFim",
       curso."cursoSituacao"                                            AS "ViewCursoCursoSituacao",
       curso."centroId"                                                 AS "ViewCursoCursoCentroId",
       curso."cursoEmail"                                               AS "ViewCursoCursoEmail",
       curso."modalidadeId"                                             AS "ViewCursoModalidadeId",
       curso."cursoHoraAula"                                            AS "ViewCursoCursoHoraAula",
       curso."cursoId"
FROM curso;

alter table "ViewCurso"
    owner to postgres;

