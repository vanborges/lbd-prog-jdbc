create function teste1(integer) returns integer
    language plpgsql
as
$$
DECLARE base ALIAS FOR $1;
        pointer RECORD;
        pointerturma RECORD;
        pointerglobal record;
        academicoturmaid integer;
        docenteTeorica integer;
        str_aux bit(2)[];
        i smallint; /* contador */
        num_faltas integer;
        num_pres integer;
        carga_horaria_total integer;
        num_faltas_total integer;
        num_pres_total integer;
        faltas integer;
        presencas integer;
        situacao char (2);
        sit char (2);
        TURMAID integer;
        CargaHorariaTurma integer;
        CargaHorariaLTDA char;
BEGIN
    num_faltas_total := 0;
    num_pres_total := 0;
    academicoturmaid := 0;
for pointerglobal in select t."turmaId"
                     from turma t
                     where t."turmaAno" in (2006, 2007, 2008) and t."turmaId" = base
                     order by t."turmaId"
                    -- offset base limit 50
loop
    TURMAID := pointerglobal."turmaId";--21453;
    TURMAID := base;
for pointerturma in select  t."academicoTurmaId" from "academicoTurma" t where t."turmaId" = TURMAID order by t."academicoTurmaId"
--and t."academicoTurmaId" = 1754862
loop
     select into CargaHorariaLTDA "estruturaCargaHorariaLimitada"
	 from estrutura e
	 where e."estruturaId" in (select distinct o."estruturaId"
                              from "cursoTurma" ct join oferta o on ( ct."ofertaId" = o."ofertaId")
                              where ct."turmaId" = TURMAID);

     -- turma tem carga horaria limitada.
     if CargaHorariaLTDA = 'S' then
        select into CargaHorariaTurma (c."cursoModulo" * 2)
        from "cursoTurma" ct ,  oferta o, curso c
        where ct."ofertaId"      = o."ofertaId" and
               o."cursoId"        = c."cursoId"    and
               o."cursoSequencia" = c."cursoSequencia" and
               ct."turmaId" = TURMAID;
     else
         SELECT into CargaHorariaTurma "ViewDiariodisciplinaCarga"
		 FROM "ViewDiario"
		 WHERE "ViewDiario"."ViewDiarioId" = TURMAID;
     end if;
    select into CargaHorariaTurma * from carga_horaria(TURMAID,null,null);
    
    for pointer in select f."frequenciaValor",f."academicoTurmaId", t."academicoTurmaFaltas", t."academicoTurmaPresenca",  t."academicoTurmaSituacao"
                   from "diaLetivo" d natural join frequencia f join "academicoTurma" t on f."academicoTurmaId" = t."academicoTurmaId"
                   where t."academicoTurmaId" = pointerturma."academicoTurmaId"
                   order by f."academicoTurmaId"
    loop
        if nullvalue(str_aux) THEN
           str_aux := pointer."frequenciaValor";
        else
            str_aux := array_cat(str_aux,pointer."frequenciaValor");
        end if;
        num_pres_total := pointer."academicoTurmaFaltas" + pointer."academicoTurmaPresenca";
        faltas    := pointer."academicoTurmaFaltas";
        presencas := pointer."academicoTurmaPresenca";
        situacao  := pointer."academicoTurmaSituacao";
    END LOOP;
    /* Se o campo buscado no banco for nulo transformar em zero.*/
    if nullvalue(faltas) THEN
       faltas := 0;
    end if;
    if nullvalue(presencas) THEN
       presencas := 0;
    end if;

    /* Atribui uma flag p/ sinalizar o fim do vetor */
    str_aux := array_append(str_aux,B'11');
    i := 1; /* o vetor começa na posição um */

    /* Iniciando as variaveis */
    num_faltas := 0;
    num_pres   := 0;

    /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
    WHILE str_aux[i] != B'11' LOOP
        if(str_aux[i] = B'01') then /* se falta */
               num_faltas:=num_faltas+1;
        elseif (str_aux[i] = B'10') then /* se presença */
              num_pres:=num_pres+1;
        elseif (str_aux[i] = B'00') then
        end if;
         i := i + 1;
     end loop;
    num_faltas_total := num_faltas ;
--raise notice 'armazenadas no banco faltas % presenca % contadas n_faltas % n_pres % str_aux %', faltas, presencas, num_faltas, num_pres, str_aux;
--raise notice 'carga horaria total %',CargaHorariaTurma;
--raise notice 'armazenadas no banco faltas % presenca % contadas n_faltas % n_pres % ', faltas, presencas, num_faltas, num_pres;
  raise notice '% armazenadas no banco faltas % presenca % contadas n_faltas % n_pres % str_aux %', pointerturma."academicoTurmaId",faltas, presencas, num_faltas, num_pres, str_aux;
    sit := NULL;
    if (num_faltas_total * 100 / CargaHorariaTurma ) > 25  then
         sit := 'RF';
    end if;
    raise notice ' sit =>%< situacao %',sit,situacao;
    -- Se o numero de faltas ou presenças estiver diferente do armazenado
    if num_faltas != faltas or num_pres != presencas then
       if sit = situacao then
          -- fazer o update sem problema, atualizar faltas + presencas
          update "academicoTurma" set "academicoTurmaPresenca" = num_pres , "academicoTurmaFaltas" = num_faltas
          where    "academicoTurmaId" = pointerturma."academicoTurmaId";
          raise notice 'fazer update de boa';
           --raise notice 'acdturmaid %  faltas = % presenca = % total = % ARMAZENADO faltas % presenca % total %', pointerturma."academicoTurmaId", num_faltas,num_pres , num_faltas_total,faltas, presencas, num_pres_total ;
       ELSEIF (sit = '' or nullvalue(sit)) and situacao = 'RF' then
           raise notice 'ALERTA aluno foi reprovado indevidamente.';
           raise notice 'acdturmaid %  faltas = % presenca = % total = % ARMAZENADO faltas % presenca % total %', pointerturma."academicoTurmaId", num_faltas,num_pres , num_faltas_total,faltas, presencas, num_pres_total ;
       ELSEIF sit = '' or nullvalue(sit) then
          raise notice 'fazer update de boa';
           --raise notice 'acdturmaid %  faltas = % presenca = % total = % ARMAZENADO faltas % presenca % total %', pointerturma."academicoTurmaId", num_faltas,num_pres , num_faltas_total,faltas, presencas, num_pres_total ;
          update "academicoTurma" set "academicoTurmaPresenca" = num_pres , "academicoTurmaFaltas" = num_faltas
          where    "academicoTurmaId" = pointerturma."academicoTurmaId";
       ELSEIF situacao = ' ' or nullvalue(sit) or situacao = '' or nullvalue(situacao) or situacao = 'MA' then
           -- fazer o update sem problema, atualizar faltas + presencas + situacao
          update "academicoTurma" set "academicoTurmaPresenca" = num_pres , "academicoTurmaFaltas" = num_faltas,
          "academicoTurmaSituacao" = sit   where    "academicoTurmaId" = pointerturma."academicoTurmaId";
           raise notice 'fazer update de boa';
           --raise notice 'acdturmaid %  faltas = % presenca = % total = % ARMAZENADO faltas % presenca % total %', pointerturma."academicoTurmaId", num_faltas,num_pres , num_faltas_total,faltas, presencas, num_pres_total ;
       else
           raise notice 'ALERTA situacoes diferentes sit % situacao %', sit, situacao;
           raise notice 'acdturmaid %  faltas = % presenca = % total = % ARMAZENADO faltas % presenca % total %', pointerturma."academicoTurmaId", num_faltas,num_pres , num_faltas_total,faltas, presencas, num_pres_total ;
       end if;
    else
       -- Se o numero total de presencas ou faltas real for maior que a carga horaria emitir alerta.
        if num_faltas_total > CargaHorariaTurma then
            raise notice 'ALERTA fudeu numero de faltas + presenca maior que carga horaria total.';
        end if;
    end if;
    str_aux = NULL;
    num_pres_total := 0;
    faltas         := 0;
    presencas      := 0;
    situacao       := 0;

   end loop;
end loop; -- loop para percorrer as turmas
    RETURN 1;
END;
$$;

alter function teste1(integer) owner to postgres;

