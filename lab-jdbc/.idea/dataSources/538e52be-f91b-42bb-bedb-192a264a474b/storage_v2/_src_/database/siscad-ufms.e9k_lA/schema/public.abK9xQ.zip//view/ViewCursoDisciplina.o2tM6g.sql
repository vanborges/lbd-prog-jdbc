create view "ViewCursoDisciplina"("ViewCursoDisciplinaId", "ViewCursoDisciplinaCentroId", "ViewCursoDisciplinaCursoId",
                                  "ViewCursoDisciplinaCursoAnoIni", "ViewCursoDisciplinaCursoSemIni",
                                  "ViewCursoDisciplinaCursoAnoFim", "ViewCursoDisciplinaCursoSemFim",
                                  "ViewCursoDisciplinaCursoCodigo", "ViewCursoDisciplinaCursoSequencia",
                                  "ViewCursoDisciplinaCursoNome", "ViewCursoDisciplinaDisciplinaId",
                                  "ViewCursoDisciplinaDisciplinaCodigo", "ViewCursoDisciplinaDisciplinaNome",
                                  "ViewCursoDisciplinaDisciplinaCarga") as
SELECT g."gradeId"          AS "ViewCursoDisciplinaId",
       c."centroId"         AS "ViewCursoDisciplinaCentroId",
       c."cursoId"          AS "ViewCursoDisciplinaCursoId",
       c."cursoAnoIni"      AS "ViewCursoDisciplinaCursoAnoIni",
       c."cursoSemIni"      AS "ViewCursoDisciplinaCursoSemIni",
       c."cursoAnoFim"      AS "ViewCursoDisciplinaCursoAnoFim",
       c."cursoSemFim"      AS "ViewCursoDisciplinaCursoSemFim",
       c."cursoCodigo"      AS "ViewCursoDisciplinaCursoCodigo",
       c."cursoSequencia"   AS "ViewCursoDisciplinaCursoSequencia",
       c."cursoNome"        AS "ViewCursoDisciplinaCursoNome",
       d."disciplinaId"     AS "ViewCursoDisciplinaDisciplinaId",
       d."disciplinaCodigo" AS "ViewCursoDisciplinaDisciplinaCodigo",
       d."disciplinaNome"   AS "ViewCursoDisciplinaDisciplinaNome",
       d."disciplinaCarga"  AS "ViewCursoDisciplinaDisciplinaCarga"
FROM (((curso c
    JOIN grade g ON ((c."cursoId" = g."cursoId")))
    JOIN disciplina d ON ((g."disciplinaId" = d."disciplinaId")))
         JOIN oferta o ON ((g."gradeId" = o."gradeId")))
ORDER BY c."cursoCodigo", c."cursoSequencia", (to_ascii((c."cursoNome")::text)), (to_ascii((d."disciplinaNome")::text));

alter table "ViewCursoDisciplina"
    owner to postgres;

