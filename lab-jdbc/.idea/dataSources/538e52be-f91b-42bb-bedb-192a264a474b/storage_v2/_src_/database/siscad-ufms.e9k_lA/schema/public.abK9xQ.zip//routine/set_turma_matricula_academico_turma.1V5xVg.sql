create function set_turma_matricula_academico_turma() returns trigger
    language plpgsql
as
$$
DECLARE sql TEXT;
BEGIN
  	--
    -- Se for update. 
    --
    IF (TG_OP = 'UPDATE') THEN

    	-- SE MUDAR A TURMA ATUALIZAR A TURMAID DA 
        -- TABELA MATRICULAACADEMICOTURMA
        IF NEW."turmaId" != OLD."turmaId" THEN
        	sql := 'UPDATE "matriculaAcademicoTurma" SET ';       
         	sql := sql || ' "turmaIdCoordenador" = ' ||  NEW."turmaId" || ', ' ;
  			sql := sql || ' "academicoTurmaTipoDisciplina" = ''' ||  NEW."academicoTurmaTipoDisciplina" || ''', ' ; 
			sql := sql || ' "academicoTurmaCargaHoraria"  = ' || NEW."academicoTurmaCargaHoraria" || ', ' ;
  			sql := sql || ' "TURMA" = ''' || NEW."TURMA" || ''', ' ;
            sql := sql || ' "CURDISC" = ''' || NEW."CURDISC" || ''', ' ;
            sql := sql || '	"matriculaAcademicoTurmaObs" = ''Turma alterada pela SECAC.''' ;            
            sql := sql || ' WHERE "academicoId" = ' || NEW."academicoId" || ' AND ';
            sql := sql || '       "disciplinaId" = ' || NEW."disciplinaId" || ' AND ';
            sql := sql || '       "ANO" = 2014 AND ';
            sql := sql || '       "SEM" = 2; ';
        
        END IF;
    --
    -- Se for delete.
    --
    ELSIF (TG_OP = 'DELETE') THEN
            sql := 'UPDATE "matriculaAcademicoTurma" SET ';       
         	sql := sql || ' "turmaIdCoordenador" = 0 , ' ;
  			sql := sql || ' "academicoTurmaTipoDisciplina" = ''OBR'' , ' ; 
			sql := sql || ' "academicoTurmaCargaHoraria"  = 0 , ' ;
  			sql := sql || ' "TURMA" = ''00'' , ' ;
            sql := sql || ' "CURDISC" = '''' , ' ;
            sql := sql || '	"matriculaAcademicoTurmaObs" = ''Matrícula excluída pela SECAC.''' ;
            sql := sql || ' WHERE "academicoId" = ' || OLD."academicoId" || ' AND ';
            sql := sql || '       "disciplinaId" = ' || OLD."disciplinaId" || ' AND ';
            sql := sql || '       "ANO" = 2014 AND ';
            sql := sql || '       "SEM" = 2; ';
    
    END IF;    
      
    IF sql != '' THEN
    	EXECUTE sql;
    END IF;
    
    --raise notice '%', sql;    
    IF (TG_OP = 'DELETE') THEN
    	RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;

END;
$$;

alter function set_turma_matricula_academico_turma() owner to postgres;

