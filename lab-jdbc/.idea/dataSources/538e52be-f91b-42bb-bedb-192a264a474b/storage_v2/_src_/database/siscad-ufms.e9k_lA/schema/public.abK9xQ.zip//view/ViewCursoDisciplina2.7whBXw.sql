create view "ViewCursoDisciplina2"("ViewCursoDisciplina2Ano", "ViewCursoDisciplina2Semestre", "ViewCursoDisciplina2Id",
                                   "ViewCursoDisciplina2CentroId", "ViewCursoDisciplina2CursoCodigo",
                                   "ViewCursoDisciplina2DisciplinaId", "ViewCursoDisciplina2DisciplinaCodigo",
                                   "ViewCursoDisciplina2DisciplinaNome", "ViewCursoDisciplina2DisciplinaCarga") as
SELECT DISTINCT o."ofertaAno"        AS "ViewCursoDisciplina2Ano",
                o."ofertaSemestre"   AS "ViewCursoDisciplina2Semestre",
                g."disciplinaId"     AS "ViewCursoDisciplina2Id",
                c."centroId"         AS "ViewCursoDisciplina2CentroId",
                c."cursoCodigo"      AS "ViewCursoDisciplina2CursoCodigo",
                d."disciplinaId"     AS "ViewCursoDisciplina2DisciplinaId",
                d."disciplinaCodigo" AS "ViewCursoDisciplina2DisciplinaCodigo",
                d."disciplinaNome"   AS "ViewCursoDisciplina2DisciplinaNome",
                d."disciplinaCarga"  AS "ViewCursoDisciplina2DisciplinaCarga"
FROM ((((((oferta o
    JOIN grade g ON ((g."gradeId" = o."gradeId")))
    JOIN turma t ON ((t."ofertaId" = o."ofertaId")))
    JOIN "cursoTurma" ct ON ((ct."turmaId" = t."turmaId")))
    JOIN disciplina d ON ((d."disciplinaId" = g."disciplinaId")))
    JOIN curso c ON ((c."cursoCodigo" = (ct."cursoCodigo")::bpchar)))
         JOIN centro ce ON ((c."centroId" = ce."centroId")))
ORDER BY o."ofertaAno", o."ofertaSemestre", c."cursoCodigo", d."disciplinaNome", c."centroId", d."disciplinaId",
         g."disciplinaId", d."disciplinaCodigo", d."disciplinaCarga";

alter table "ViewCursoDisciplina2"
    owner to postgres;

