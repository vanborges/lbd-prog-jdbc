create view dados_alunos(rga, idade, sexo, qtde_faltas, disciplina_id, tipo_disciplina, media, situacao, nota1, nota2,
                         nota3, nota4, nota5, nota6, nota7, nota8, nota9, nota10) as
    WITH dados AS (
        SELECT a."academicoRga"                                                              AS rga,
               date_part('year'::text, age((a."academicoDtNasc")::timestamp with time zone)) AS idade,
               a."academicoSexo"                                                             AS sexo,
               at."academicoTurmaFaltas"                                                     AS qtde_faltas,
               d_1."disciplinaId"                                                            AS disciplina_id,
               at."academicoTurmaTipoDisciplina"                                             AS tipo_disciplina,
               at."academicoTurmaNota"                                                       AS media,
               at."academicoTurmaSituacao"                                                   AS situacao,
               ARRAY(SELECT n1."notaValor"
                     FROM nota n1
                     WHERE (n1."academicoTurmaId" = at."academicoTurmaId")
                     ORDER BY n1."avaliacaoId")                                              AS notas
        FROM ((academico a
            JOIN "academicoTurma" at ON ((a."academicoId" = at."academicoId")))
                 JOIN disciplina d_1 ON ((at."disciplinaId" = d_1."disciplinaId")))
    )
    SELECT d.rga,
           d.idade,
           d.sexo,
           d.qtde_faltas,
           d.disciplina_id,
           d.tipo_disciplina,
           d.media,
           d.situacao,
           d.notas[1]  AS nota1,
           d.notas[2]  AS nota2,
           d.notas[3]  AS nota3,
           d.notas[4]  AS nota4,
           d.notas[5]  AS nota5,
           d.notas[6]  AS nota6,
           d.notas[7]  AS nota7,
           d.notas[8]  AS nota8,
           d.notas[9]  AS nota9,
           d.notas[10] AS nota10
    FROM dados d;

alter table dados_alunos
    owner to postgres;

