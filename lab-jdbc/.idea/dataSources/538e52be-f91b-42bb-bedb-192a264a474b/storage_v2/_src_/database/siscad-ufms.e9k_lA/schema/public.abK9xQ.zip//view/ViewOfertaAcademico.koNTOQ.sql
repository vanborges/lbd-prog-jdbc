create view "ViewOfertaAcademico"("ViewOfertaAcademicoOfertaAno", "ViewOfertaAcademicoOfertaSemestre",
                                  "ViewOfertaAcademicoOfertaPeriodoEspecial", "ViewOfertaAcademicoDisciplinaId",
                                  "ViewOfertaAcademicoDisciplinaCodigo", "ViewOfertaAcademicoDisciplinaNome",
                                  "ViewOfertaAcademicoDisciplinaCarga", "ViewOfertaAcademicoCursoCodigo",
                                  "ViewOfertaAcademicoId") as
SELECT DISTINCT o."ofertaAno"             AS "ViewOfertaAcademicoOfertaAno",
                o."ofertaSemestre"        AS "ViewOfertaAcademicoOfertaSemestre",
                o."ofertaPeriodoEspecial" AS "ViewOfertaAcademicoOfertaPeriodoEspecial",
                d."disciplinaId"          AS "ViewOfertaAcademicoDisciplinaId",
                d."disciplinaCodigo"      AS "ViewOfertaAcademicoDisciplinaCodigo",
                d."disciplinaNome"        AS "ViewOfertaAcademicoDisciplinaNome",
                d."disciplinaCarga"       AS "ViewOfertaAcademicoDisciplinaCarga",
                ct."cursoCodigo"          AS "ViewOfertaAcademicoCursoCodigo",
                d."disciplinaId"          AS "ViewOfertaAcademicoId"
FROM ((((disciplina d
    JOIN grade g ON ((d."disciplinaId" = g."disciplinaId")))
    JOIN oferta o ON ((g."gradeId" = o."gradeId")))
    JOIN turma t ON ((t."ofertaId" = o."ofertaId")))
         JOIN "cursoTurma" ct ON ((ct."turmaId" = t."turmaId")))
ORDER BY o."ofertaAno", o."ofertaSemestre", o."ofertaPeriodoEspecial", d."disciplinaNome", d."disciplinaId",
         d."disciplinaCodigo", d."disciplinaCarga", ct."cursoCodigo";

alter table "ViewOfertaAcademico"
    owner to postgres;

