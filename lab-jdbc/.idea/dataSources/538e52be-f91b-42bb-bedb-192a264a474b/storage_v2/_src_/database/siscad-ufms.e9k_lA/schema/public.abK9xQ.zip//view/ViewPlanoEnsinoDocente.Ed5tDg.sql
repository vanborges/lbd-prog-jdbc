create view "ViewPlanoEnsinoDocente"("ViewPlanoEnsinoDocenteId", "ViewPlanoEnsinoDocentedisciplinaCodigo",
                                     "ViewPlanoEnsinoDocentedisciplinaNome", "ViewPlanoEnsinoDocentedisciplinaCarga",
                                     "ViewPlanoEnsinoDocenteturmaTipo", "ViewPlanoEnsinoDocenteturmaNome", "foreignId",
                                     "ViewPlanoEnsinoDocenteofertaId", "ViewPlanoEnsinoDocenteAno",
                                     "ViewPlanoEnsinoDocenteofertaSemestre", "ViewPlanoEnsinoDocenteofertaDuracao",
                                     "ViewPlanoEnsinoDocentecursoId", "ViewPlanoEnsinoDocentecursoCodigo",
                                     "ViewPlanoEnsinoDocentecursoSequencia", "ViewPlanoEnsinoDocentecursoNome",
                                     "ViewPlanoEnsinoDocentedepartamentoSigla",
                                     "ViewPlanoEnsinoDocentedepartamentoNome", "ViewPlanoEnsinoDocentecentroSigla",
                                     "ViewPlanoEnsinoDocentecentroNome", "ViewPlanoEnsinoDocenteplanoEnsinoId",
                                     "ViewPlanoEnsinoDocenteturmaBloqueio", "ViewPlanoEnsinoDocenteAprovcolegiado",
                                     "ViewPlanoEnsinoDocenteAprovdepto", "ViewPlanoEnsinoDocentedataUltimaAlteracao",
                                     "ViewPlanoEnsinoDocenteusrName", "ViewPlanoEnsinoDocenteLiberado",
                                     "ViewPlanoEnsinoDocentedocenteId") as
    (SELECT DISTINCT turma."turmaId"                                       AS "ViewPlanoEnsinoDocenteId",
                     disciplina."disciplinaCodigo"                         AS "ViewPlanoEnsinoDocentedisciplinaCodigo",
                     disciplina."disciplinaNome"                           AS "ViewPlanoEnsinoDocentedisciplinaNome",
                     disciplina."disciplinaCarga"                          AS "ViewPlanoEnsinoDocentedisciplinaCarga",
                     turma."turmaTipo"                                     AS "ViewPlanoEnsinoDocenteturmaTipo",
                     turma."turmaNome"                                     AS "ViewPlanoEnsinoDocenteturmaNome",
                     "docenteTurma"."docenteId"                            AS "foreignId",
                     oferta."ofertaId"                                     AS "ViewPlanoEnsinoDocenteofertaId",
                     oferta."ofertaAno"                                    AS "ViewPlanoEnsinoDocenteAno",
                     oferta."ofertaSemestre"                               AS "ViewPlanoEnsinoDocenteofertaSemestre",
                     oferta."ofertaDuracao"                                AS "ViewPlanoEnsinoDocenteofertaDuracao",
                     curso."cursoId"                                       AS "ViewPlanoEnsinoDocentecursoId",
                     curso."cursoCodigo"                                   AS "ViewPlanoEnsinoDocentecursoCodigo",
                     curso."cursoSequencia"                                AS "ViewPlanoEnsinoDocentecursoSequencia",
                     curso."cursoNome"                                     AS "ViewPlanoEnsinoDocentecursoNome",
                     departamento."departamentoSigla"                      AS "ViewPlanoEnsinoDocentedepartamentoSigla",
                     departamento."departamentoNome"                       AS "ViewPlanoEnsinoDocentedepartamentoNome",
                     centro."centroSigla"                                  AS "ViewPlanoEnsinoDocentecentroSigla",
                     centro."centroNome"                                   AS "ViewPlanoEnsinoDocentecentroNome",
                     turma."planoEnsinoId"                                 AS "ViewPlanoEnsinoDocenteplanoEnsinoId",
                     ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint) AS "ViewPlanoEnsinoDocenteturmaBloqueio",
                     "planoEnsinoAprovacao"."dataAprovacaoColegiado"       AS "ViewPlanoEnsinoDocenteAprovcolegiado",
                     "planoEnsino"."planoEnsinoAprovdepto"                 AS "ViewPlanoEnsinoDocenteAprovdepto",
                     "planoEnsino"."planoEnsinoDataUltimaAlteracao"        AS "ViewPlanoEnsinoDocentedataUltimaAlteracao",
                     usr."usrName"                                         AS "ViewPlanoEnsinoDocenteusrName",
                     "planoEnsino"."planoEnsinoLiberado"                   AS "ViewPlanoEnsinoDocenteLiberado",
                     "docenteTurma"."docenteId"                            AS "ViewPlanoEnsinoDocentedocenteId"
     FROM (((((((((((("docenteTurma"
         JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaId")))
         JOIN "cursoTurma" ON (("cursoTurma"."turmaId" = turma."turmaId")))
         JOIN oferta ON ((turma."ofertaId" = oferta."ofertaId")))
         JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
         JOIN curso ON ((grade."cursoId" = curso."cursoId")))
         JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
         JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
         JOIN centro ON ((departamento."centroId" = centro."centroId")))
         LEFT JOIN "planoEnsino" ON ((turma."planoEnsinoId" = "planoEnsino"."planoEnsinoId")))
         LEFT JOIN usr ON ((usr."usrId" = "planoEnsino"."usrId")))
         LEFT JOIN "usrSystem" ON (("usrSystem"."usrId" = usr."usrId")))
              LEFT JOIN "planoEnsinoAprovacao"
                        ON (("planoEnsino"."planoEnsinoId" = "planoEnsinoAprovacao"."planoEnsinoId")))
     WHERE ((turma."turmaIsFather" IS FALSE) AND
            (("cursoTurma"."cursoTurmaId" = "planoEnsinoAprovacao"."cursoTurmaId") OR
             ("planoEnsinoAprovacao"."cursoTurmaId" IS NULL)))
     ORDER BY turma."turmaId", disciplina."disciplinaCodigo", disciplina."disciplinaNome", disciplina."disciplinaCarga",
              turma."turmaTipo", turma."turmaNome", "docenteTurma"."docenteId", oferta."ofertaId", oferta."ofertaAno",
              oferta."ofertaSemestre", oferta."ofertaDuracao", curso."cursoId", curso."cursoSequencia",
              curso."cursoNome", departamento."departamentoSigla", departamento."departamentoNome",
              centro."centroSigla", centro."centroNome", turma."planoEnsinoId",
              ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint), "planoEnsinoAprovacao"."dataAprovacaoColegiado",
              "planoEnsino"."planoEnsinoAprovdepto", "planoEnsino"."planoEnsinoDataUltimaAlteracao", usr."usrName",
              curso."cursoCodigo", "planoEnsino"."planoEnsinoLiberado")
    UNION
    (SELECT DISTINCT turma."turmaId"                                       AS "ViewPlanoEnsinoDocenteId",
                     disciplina."disciplinaCodigo"                         AS "ViewPlanoEnsinoDocentedisciplinaCodigo",
                     disciplina."disciplinaNome"                           AS "ViewPlanoEnsinoDocentedisciplinaNome",
                     disciplina."disciplinaCarga"                          AS "ViewPlanoEnsinoDocentedisciplinaCarga",
                     turma."turmaTipo"                                     AS "ViewPlanoEnsinoDocenteturmaTipo",
                     turma."turmaNome"                                     AS "ViewPlanoEnsinoDocenteturmaNome",
                     "docenteTurma"."docenteId"                            AS "foreignId",
                     oferta."ofertaId"                                     AS "ViewPlanoEnsinoDocenteofertaId",
                     oferta."ofertaAno"                                    AS "ViewPlanoEnsinoDocenteAno",
                     oferta."ofertaSemestre"                               AS "ViewPlanoEnsinoDocenteofertaSemestre",
                     oferta."ofertaDuracao"                                AS "ViewPlanoEnsinoDocenteofertaDuracao",
                     curso."cursoId"                                       AS "ViewPlanoEnsinoDocentecursoId",
                     curso."cursoCodigo"                                   AS "ViewPlanoEnsinoDocentecursoCodigo",
                     curso."cursoSequencia"                                AS "ViewPlanoEnsinoDocentecursoSequencia",
                     curso."cursoNome"                                     AS "ViewPlanoEnsinoDocentecursoNome",
                     departamento."departamentoSigla"                      AS "ViewPlanoEnsinoDocentedepartamentoSigla",
                     departamento."departamentoNome"                       AS "ViewPlanoEnsinoDocentedepartamentoNome",
                     centro."centroSigla"                                  AS "ViewPlanoEnsinoDocentecentroSigla",
                     centro."centroNome"                                   AS "ViewPlanoEnsinoDocentecentroNome",
                     turma."planoEnsinoId"                                 AS "ViewPlanoEnsinoDocenteplanoEnsinoId",
                     ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint) AS "ViewPlanoEnsinoDocenteturmaBloqueio",
                     "planoEnsinoAprovacao"."dataAprovacaoColegiado"       AS "ViewPlanoEnsinoDocenteAprovcolegiado",
                     "planoEnsino"."planoEnsinoAprovdepto"                 AS "ViewPlanoEnsinoDocenteAprovdepto",
                     "planoEnsino"."planoEnsinoDataUltimaAlteracao"        AS "ViewPlanoEnsinoDocentedataUltimaAlteracao",
                     usr."usrName"                                         AS "ViewPlanoEnsinoDocenteusrName",
                     "planoEnsino"."planoEnsinoLiberado"                   AS "ViewPlanoEnsinoDocenteLiberado",
                     "docenteTurma"."docenteId"                            AS "ViewPlanoEnsinoDocentedocenteId"
     FROM (((((((((((("docenteTurma"
         JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaPai")))
         JOIN "cursoTurma" ON (("cursoTurma"."turmaId" = turma."turmaId")))
         JOIN oferta ON ((turma."ofertaId" = oferta."ofertaId")))
         JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
         JOIN curso ON ((grade."cursoId" = curso."cursoId")))
         JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
         JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
         JOIN centro ON ((departamento."centroId" = centro."centroId")))
         LEFT JOIN "planoEnsino" ON ((turma."planoEnsinoId" = "planoEnsino"."planoEnsinoId")))
         LEFT JOIN usr ON ((usr."usrId" = "planoEnsino"."usrId")))
         LEFT JOIN "usrSystem" ON (("usrSystem"."usrId" = usr."usrId")))
              LEFT JOIN "planoEnsinoAprovacao"
                        ON (("planoEnsino"."planoEnsinoId" = "planoEnsinoAprovacao"."planoEnsinoId")))
     WHERE ((turma."turmaIsFather" IS FALSE) AND
            (("cursoTurma"."cursoTurmaId" = "planoEnsinoAprovacao"."cursoTurmaId") OR
             ("planoEnsinoAprovacao"."cursoTurmaId" IS NULL)))
     ORDER BY turma."turmaId", disciplina."disciplinaCodigo", disciplina."disciplinaNome", disciplina."disciplinaCarga",
              turma."turmaTipo", turma."turmaNome", "docenteTurma"."docenteId", oferta."ofertaId", oferta."ofertaAno",
              oferta."ofertaSemestre", oferta."ofertaDuracao", curso."cursoId", curso."cursoSequencia",
              curso."cursoNome", departamento."departamentoSigla", departamento."departamentoNome",
              centro."centroSigla", centro."centroNome", turma."planoEnsinoId",
              ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint), "planoEnsinoAprovacao"."dataAprovacaoColegiado",
              "planoEnsino"."planoEnsinoAprovdepto", usr."usrName", curso."cursoCodigo",
              "planoEnsino"."planoEnsinoLiberado", "planoEnsino"."planoEnsinoDataUltimaAlteracao");

alter table "ViewPlanoEnsinoDocente"
    owner to postgres;

