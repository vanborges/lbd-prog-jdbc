create function f_isvalidemail(text) returns boolean
    language sql
as
$$
select $1 ~ '^[^@s]+@[^@s]+(.[^@s]+)+$' as result
$$;

alter function f_isvalidemail(text) owner to postgres;

