create function atualizafrequencia() returns trigger
    language plpgsql
as
$$
DECLARE faltas integer;
DECLARE pres integer;
DECLARE i integer;
DECLARE str_aux bit(2)[];
DECLARE sit varchar(2);
DECLARE carga_lim char;
DECLARE turmaID integer;
DECLARE faltas_atual integer;
DECLARE carga_horaria real;

BEGIN
	/* Vetor auxiliar para se deslocar no registro de frequencia */
	str_aux := OLD."frequenciaValor";
	str_aux := array_append(str_aux,B'11');

	/* Atribui uma flag p/ sinalizar o fim do vetor */
	str_aux := array_append(str_aux,B'11');

	i := 1; /* o vetor começa na posição um */

          /* Iniciando as variaveis */
	faltas := 0;
	faltas_atual:=0;
	pres   := 0;

	/*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
	WHILE str_aux[i] != B'11' LOOP
		if(str_aux[i] = B'01') then /* se falta */
			faltas:=faltas+1;
		elseif (str_aux[i] = B'10') then /* se presença */
			pres:=pres+1;
		elseif (str_aux[i] = B'00') then
		end if;
			i := i + 1;
	END LOOP;
	/*
               Busca saber se ha a necessidade de se atualizar o campo falta e consequentemente
               a situacao de Reprovado por falta
           */
	if faltas!=0 then
		/*Busca informacoes necessarias na acad Turma*/
		select at."academicoTurmaSituacao",at."turmaId",at."academicoTurmaFaltas" into sit,turmaID,faltas_atual
		from "academicoTurma" at
		where at."academicoTurmaId"=OLD."academicoTurmaId";

		/*O academico ja se encontra reprovado por faltas*/
		if sit = 'RF' then
			/*Busca saber se a carga horaria eh limitada*/
			select e."estruturaCargaHorariaLimitada" into carga_lim
			from estrutura e
			where e."estruturaId" in (              
            select e."estruturaId"
            from oferta o
                 join grade g on o."gradeId" = g."gradeId"
                 join estrutura e on g."estruturaId" = e."estruturaId"
                 join turma t on t."ofertaId" = o."ofertaId"
            where t."turmaId" = turmaID);            

			/*Carga horaria eh limitada*/
			if carga_lim = 'S' then
				select (c."cursoModulo"*2) into carga_horaria
                 from oferta o
                 join grade g on o."gradeId" = g."gradeId"
                 join curso c on g."cursoId"=c."cursoId"
                 join estrutura e on g."estruturaId" = e."estruturaId"
                 join turma t on t."ofertaId" = o."ofertaId"
                 where t."turmaId"=turmaID;
			else
				SELECT vd."ViewDiariodisciplinaCarga" into carga_horaria
				from "ViewDiario" vd
				where vd."ViewDiarioId" = turmaID;
			end if;
			/*O academico nao esta mais reprovado por faltas*/
			if (( (faltas_atual - faltas) / carga_horaria)*100)<25 then
				update  "academicoTurma" set "academicoTurmaPresenca" = "academicoTurmaPresenca" - pres,
				"academicoTurmaFaltas" = "academicoTurmaFaltas" - faltas,
				"academicoTurmaSituacao"=''
				where "academicoTurmaId" = OLD."academicoTurmaId";
			ELSE
				/* O academico continua reprovado por faltas, so atualizando o numero de faltas e presencas */
				update  "academicoTurma" set "academicoTurmaPresenca" = "academicoTurmaPresenca" - pres,
				"academicoTurmaFaltas" = "academicoTurmaFaltas" - faltas
				where "academicoTurmaId" = OLD."academicoTurmaId";
			end if;

		else
			 /*Academico não era Reprovado por faltas, faz um update sem se preoucupar com a situacao */
			update  "academicoTurma" set "academicoTurmaPresenca" = "academicoTurmaPresenca" - pres,
			"academicoTurmaFaltas" = "academicoTurmaFaltas" - faltas
			where "academicoTurmaId" = OLD."academicoTurmaId";
		end if;
	else
		/*Faltas == 0, deve entao verificar o numero de presencas*/
		if pres!=0 then
			update  "academicoTurma" set "academicoTurmaPresenca" = "academicoTurmaPresenca" - pres
			-- , "academicoTurmaFaltas" = 0 :não signif. que apagando 1 dia Letivo vai zerar o numero de faltas. 
			where "academicoTurmaId" = OLD."academicoTurmaId";
		end if;
	end if;
RETURN OLD;
END;
$$;

alter function atualizafrequencia() owner to postgres;

