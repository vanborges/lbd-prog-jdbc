create function strip_tags(text) returns text
    language sql
as
$$
SELECT regexp_replace(
        regexp_replace($1, E'(?x)<[^>]*?(\s alt \s* = \s* ([\'"]) ([^>]*?) \2) [^>]*? >', E'\3'), 
       E'(?x)(< [^>]*? >)', '', 'g')
$$;

alter function strip_tags(text) owner to postgres;

