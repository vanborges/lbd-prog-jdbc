create view "ViewCursoGRH"("ViewCursoGRHcursoCodigo", "ViewCursoGRHcursoNome", "ViewCursoGRHcentroSigla",
                           "ViewCursoGRHcentroNome") as
SELECT c."cursoCodigo"  AS "ViewCursoGRHcursoCodigo",
       c."cursoNome"    AS "ViewCursoGRHcursoNome",
       ce."centroSigla" AS "ViewCursoGRHcentroSigla",
       ce."centroNome"  AS "ViewCursoGRHcentroNome"
FROM (curso c
         JOIN centro ce ON ((c."centroId" = ce."centroId")))
WHERE (c."cursoSituacao" = 'I'::bpchar);

alter table "ViewCursoGRH"
    owner to postgres;

