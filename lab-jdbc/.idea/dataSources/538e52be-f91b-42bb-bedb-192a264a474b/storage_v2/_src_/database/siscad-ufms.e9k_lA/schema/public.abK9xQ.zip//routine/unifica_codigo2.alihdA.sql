create function unifica_codigo2(grade1 integer, grade2 integer) returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE
 grade1 ALIAS FOR $1;
 grade2 ALIAS FOR $2;
 
 disciplina_codigo1 char(11);
 disciplina_codigo2 char(11);
 curso_codigo char(4);
 
 CURDISC1 char(4);
 CURDISC2 char(4);
 
 ofertaId1 int;
 ofertaId2 int;
 
 curdiscSubstituida char(4);
 curdiscMantida char(4);

 /* Ano para o qual a unificacao esta sendo feita */
 ano integer;

 /* O peso de cada disciplina sera usado para decidir qual codigo devera permanecer*/
 disciplina1_peso integer;
 disciplina2_peso integer;
 
 disciplinaId1 integer;
 disciplinaId2 integer;
 
 gradeIdSubstituida integer;
 
 /* Total de academicos matriculados em cada disciplina */
 total_acd_disc1 integer;
 total_acd_disc2 integer;
 /* Total de grades onde cada disciplina aparece */
 total_grade_disc1 integer;
 total_grade_disc2 integer;
 /* Total de ofertas de cada disciplina */
 total_ofertas_disc1 integer;
 total_ofertas_disc2 integer;
 codigoDisciplinaSubstituida char(11);
 codigoDisciplinaMantida char(11);
 disciplinaIdMantida integer;
 disciplinaIdSubstituida integer;
 query text;
 pointer RECORD;


BEGIN
    disciplina1_peso := 0;
    disciplina2_peso := 0;
    ano              := 2010;

    -- busca as infomações a partir da grade
        
    FOR pointer IN select d."disciplinaCodigo", c."cursoCodigo" , d."disciplinaId", o."ofertaId"
                   from disciplina d join grade g On d."disciplinaId" = g."disciplinaId"
                                     join curso c on g."cursoId" = c."cursoId"
                                     left join oferta o on g."gradeId" = o."gradeId"
                    where g."gradeId" = grade1 and c."cursoAnoIni" >= ano  LOOP
       disciplina_codigo1 :=pointer."disciplinaCodigo";
       disciplinaId1 := pointer."disciplinaId";
       CURDISC1 :=pointer."cursoCodigo";                         
       ofertaId1 := pointer."ofertaId";
    end Loop;                

    FOR pointer IN select d."disciplinaCodigo", c."cursoCodigo" ,d."disciplinaId", o."ofertaId"
                   from disciplina d join grade g On d."disciplinaId" = g."disciplinaId"
                                     join curso c on g."cursoId" = c."cursoId"
                                     left join oferta o on g."gradeId" = o."gradeId"
                    where g."gradeId" = grade2 and c."cursoAnoIni" >= ano  LOOP
       disciplina_codigo2 :=pointer."disciplinaCodigo";
       disciplinaId2 := pointer."disciplinaId";
       CURDISC2 :=pointer."cursoCodigo";                         
       ofertaId2 := pointer."ofertaId";
    end Loop;                

   
    -- exibe a oferta da disciplina
    
    raise notice 'DISCOD: %  OFERTAID:%',disciplina_codigo1, ofertaId1;
    raise notice 'DISCOD: %  OFERTAID:%',disciplina_codigo2, ofertaId2;
    
    -- Verifica se tem academico na 1 disciplina
    select into total_acd_disc1 count(*) from "academicoTurma" t
    where t."DISC" = disciplina_codigo1 and t."ANO" = ano and t."CURDISC" = CURDISC1;

    -- Verifica se tem academico na 2 disciplina
    select into total_acd_disc2 count(*)  from "academicoTurma" t
    where t."DISC" = disciplina_codigo2 and t."ANO" = ano and t."CURDISC" = CURDISC2;

    IF total_acd_disc1 > 0  THEN
       disciplina1_peso := disciplina1_peso + 50;
    END IF;

    IF total_acd_disc2 > 0  THEN
       disciplina2_peso := disciplina2_peso + 50;
    END IF;

    -- Verifica a situacao do academico na 1 disciplina
    select into total_acd_disc1 count(*) from "academicoTurma" t
    where t."DISC" = disciplina_codigo1 and t."ANO" = ano and t."CURDISC" = CURDISC1
          and t."academicoTurmaPregSituacao" in ('AP','RN', 'RF', 'DS','DC','RP');

    -- Verifica a situacao do academico na 2 disciplina
    select into total_acd_disc2 count(*) from "academicoTurma" t
    where t."DISC" = disciplina_codigo2 and t."ANO" = ano and t."CURDISC" = CURDISC2
           and t."academicoTurmaPregSituacao" in ('AP','RN', 'RF', 'DS','DC','RP');

    IF total_acd_disc1 > 0  THEN
       disciplina1_peso := disciplina1_peso + 45;
    END IF;

    IF total_acd_disc2 > 0  THEN
       disciplina2_peso := disciplina2_peso + 45;
    END IF;

    -- Verifica o total de grades que a disciplina aparece para disciplina 1
    select into total_grade_disc1 count(*)
    from curso c join grade g on c."cursoId" = g."cursoId"
             join disciplina d on d."disciplinaId" = g."disciplinaId"
    where c."cursoAnoIni" >= ano and d."disciplinaCodigo" = disciplina_codigo1; -- and c."cursoCodigo" = curso_codigo;

    -- Verifica o total de grades que a disciplina aparece para disciplina 2
    select into total_grade_disc2 count(*)
    from curso c join grade g on c."cursoId" = g."cursoId"
             join disciplina d on d."disciplinaId" = g."disciplinaId"
    where c."cursoAnoIni" >= ano and d."disciplinaCodigo" = disciplina_codigo2; -- and c."cursoCodigo" = curso_codigo;

    IF total_grade_disc1 > total_grade_disc2  THEN
       disciplina1_peso := disciplina1_peso + 20;
    ELSE
       disciplina2_peso := disciplina2_peso + 20;
    END IF;

    -- Verifica o total de ofertas para a disciplina 1

    select into total_ofertas_disc1 count(*)
    from curso c join grade g on c."cursoId" = g."cursoId"
             join disciplina d on d."disciplinaId" = g."disciplinaId"
             join oferta o on g."gradeId" = o."gradeId"
    where c."cursoAnoIni" >= ano and d."disciplinaCodigo" = disciplina_codigo1;

    --  Verifica o total de ofertas para a disciplina 2

    select into total_ofertas_disc2 count(*)
    from curso c join grade g on c."cursoId" = g."cursoId"
             join disciplina d on d."disciplinaId" = g."disciplinaId"
             join oferta o on g."gradeId" = o."gradeId"
    where c."cursoAnoIni" >= ano and d."disciplinaCodigo" = disciplina_codigo2;

    IF total_ofertas_disc1 > 0  THEN
       disciplina1_peso := disciplina1_peso + 100;
    END IF;

    IF total_ofertas_disc2 > 0  THEN
       disciplina2_peso := disciplina2_peso + 100;
    END IF;

    if disciplina2_peso > disciplina1_peso then
       raise notice 'Substituir : %',disciplina_codigo1;
       curdiscSubstituida := CURDISC1;
       codigoDisciplinaSubstituida := disciplina_codigo1;
       curdiscMantida := CURDISC2;
       codigoDisciplinaMantida := disciplina_codigo2;
       disciplinaIdSubstituida := disciplinaId1;
       disciplinaIdMantida     := disciplinaId2;
       gradeIdSubstituida := grade1;
    else    
        raise notice 'Substituir : %' ,disciplina_codigo2;
        curdiscSubstituida := CURDISC2;
        codigoDisciplinaSubstituida := disciplina_codigo2;
        curdiscMantida := CURDISC1;
        codigoDisciplinaMantida := disciplina_codigo1;
       disciplinaIdSubstituida := disciplinaId2;
       disciplinaIdMantida     := disciplinaId1;        
       gradeIdSubstituida := grade2;
    end if;

    -- select into disciplinaIdSubstituida "disciplinaId" from disciplina where "disciplinaCodigo" = codigoDisciplinaSubstituida;
    -- select into disciplinaIdMantida "disciplinaId" from disciplina where "disciplinaCodigo" = codigoDisciplinaMantida;

    raise notice 'total da  % : %', disciplina_codigo1, disciplina1_peso;
    raise notice 'total da  % : %', disciplina_codigo2, disciplina2_peso;
    


    -- atualizando a disciplinaId no academicoTurma
    query := 'update "academicoTurma" set 
                     "DISC"         = ''' || codigoDisciplinaMantida     || ''' , 
                     "disciplinaId" = ''' || disciplinaIdMantida         || '''
              where  "DISC"         = ''' || codigoDisciplinaSubstituida || ''' and 
                     "disciplinaId" = ''' || disciplinaIdSubstituida     || ''' and 
                     "ANO"          = ''' || ano                         || ''' AND  
                     "CURDISC"     = ''' || curdiscSubstituida          || '''';
    
    raise notice 'SQL : % ;', query;

    -- atualizando o disciplinaId na turma
    query := 'update turma set "DISCIPLINA" = ''' || codigoDisciplinaMantida || ''' where turma."ofertaId" in
    (
      select o."ofertaId" from curso c join grade g on c."cursoId" = g."cursoId"
                                    join oferta o on g."gradeId" = o."gradeId"
     where c."cursoAnoIni" >= ' || ano || ' and g."disciplinaId" = ' || disciplinaIdSubstituida || ' AND
      c."cursoCodigo" =  ''' || curdiscSubstituida    || ''' )';
    raise notice 'SQL : %;', query;

    -- atualizando o disciplinaId na oferta

    query := 'update oferta set "_disciplinaId" =  ' || disciplinaIdMantida || ' where oferta."gradeId"  = ' || gradeIdSubstituida ;

    raise notice 'SQL : %;', query;

     -- atualizando o disciplinaId na grade
     query := 'update grade set "disciplinaId" = ' || disciplinaIdMantida || ' where "gradeId" =  ' || gradeIdSubstituida;

     raise notice 'SQL : %;', query;

     return 1;
END;
$$;

alter function unifica_codigo2(integer, integer) owner to postgres;

