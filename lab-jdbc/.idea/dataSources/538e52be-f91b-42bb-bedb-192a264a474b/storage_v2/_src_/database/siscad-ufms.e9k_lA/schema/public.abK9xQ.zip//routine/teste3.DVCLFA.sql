create function teste3(integer) returns integer
    language plpgsql
as
$$
DECLARE base ALIAS FOR $1;
        pointer RECORD;
        pointerturma RECORD;
        pointerglobal record;
        academicoturmaid integer;
        docenteTeorica integer;
        str_aux bit(2)[];
        i smallint; /* contador */
        num_faltas integer;
        num_pres integer;
        carga_horaria_total integer;
        num_faltas_total integer;
        num_pres_total integer;
        faltas integer;
        presencas integer;
        situacao char (2);
        sit char (2);
		num_dias float;
        TURMAID integer;
        CargaHorariaTurma integer;
        CargaHorariaLTDA char;
BEGIN
    num_faltas_total := 0;
    num_pres_total := 0;
    academicoturmaid := 0;

    -- LSVU: Mudei o select abaixo para pegar todas as turmas a partir de 2006
        ACADEMICOTURMAID := base;
        for pointerturma in select t."academicoTurmaId", t."turmaId"
            from "academicoTurma" t
            where t."academicoTurmaId" = ACADEMICOTURMAID
            and t."academicoTurmaBloqueioMF" = 2
            order by t."academicoTurmaId"
        loop
            select into CargaHorariaLTDA "estruturaCargaHorariaLimitada"
	               from estrutura e
                   where e."estruturaId" in (select distinct o."estruturaId"
                         from "cursoTurma" ct
                         join oferta o on ( ct."ofertaId" = o."ofertaId")
                         where ct."turmaId" = pointerturma."turmaId");

            -- turma tem carga horaria limitada.
            if CargaHorariaLTDA = 'S' then
               select into CargaHorariaTurma (c."cursoModulo" * 2)
                      from "cursoTurma" ct ,  oferta o, curso c
                      where ct."ofertaId" = o."ofertaId"
                      and o."cursoId" = c."cursoId"
                      and o."cursoSequencia" = c."cursoSequencia"
                      and ct."turmaId" = pointerturma."turmaId";
            else
                SELECT into CargaHorariaTurma "ViewDiariodisciplinaCarga"
                FROM "ViewDiario"
		        WHERE "ViewDiario"."ViewDiarioId" = pointerturma."turmaId";
            end if;

            select into CargaHorariaTurma * from carga_horaria(pointerturma."turmaId",null,null);

	        num_dias := 0;

            -- LSVU: Alterei este sql colocando RIGHT JOIN na relação com "academicoTurma"
            --       e no WHERE para pegar somente os academicos que ainda não foram liberados para a PREG
            for pointer in select f."frequenciaValor",f."academicoTurmaId",
                t."academicoTurmaFaltas", t."academicoTurmaPresenca",
                t."academicoTurmaSituacao", d."diaLetivoCargaHorariaDia"
                from "academicoTurma" t
                left join frequencia f on f."academicoTurmaId" = t."academicoTurmaId"
                left join "diaLetivo" d on f."diaLetivoId" = d."diaLetivoId"
                where t."academicoTurmaId" = pointerturma."academicoTurmaId"
                and t."academicoTurmaBloqueioMF" = 2
                order by f."academicoTurmaId"
            loop
                if nullvalue(str_aux) then
                   str_aux := pointer."frequenciaValor";
                else
                    if not nullvalue(pointer."frequenciaValor") then
                       str_aux := array_cat(str_aux,pointer."frequenciaValor");
                    end if;
                end if;

		        num_dias := num_dias + pointer."diaLetivoCargaHorariaDia";
                num_pres_total := pointer."academicoTurmaFaltas" + pointer."academicoTurmaPresenca";
                faltas := pointer."academicoTurmaFaltas";
                presencas := pointer."academicoTurmaPresenca";
                situacao := pointer."academicoTurmaSituacao";
            end loop;

            /* Se o campo buscado no banco for nulo transformar em zero.*/
            if nullvalue(faltas) then
               faltas := 0;
            end if;
            if nullvalue(presencas) then
               presencas := 0;
            end if;

            /* Atribui uma flag p/ sinalizar o fim do vetor */
            /*      str_aux := array_append(str_aux,B'11');*/

            /* o vetor começa na posição um */
            i := 1;

            /* Iniciando as variaveis */
            num_faltas := 0;
            num_pres := 0;

            /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
            while i <= num_dias loop
                  if(str_aux[i] = B'01') then /* se falta */
                      num_faltas:=num_faltas+1;
                  elseif (str_aux[i] = B'10') then /* se presença */
                      num_pres:=num_pres+1;
                  end if;
                  raise notice 'str_aux[%] = %', i, str_aux[i];
                  i := i + 1;
            end loop;

            num_faltas_total := num_faltas ;
            raise notice 'academicoTurmaId: % Número de dias letivos: % Armazenado no Banco [%F, %P] Recalculado [%F, %P] str_aux %', pointerturma."academicoTurmaId",num_dias, faltas, presencas, num_faltas, num_pres, str_aux;

            sit := NULL;
            if (num_faltas_total * 100 / CargaHorariaTurma ) > 25  then
               sit := 'RF';
            end if;
            raise notice ' sit =>%< situacao %',sit,situacao;

            -- Se o numero de faltas ou presenças estiver diferente do armazenado
            if num_faltas != faltas or num_pres != presencas then
               if sit = 'RF' then
                   update "academicoTurma" set "academicoTurmaPresenca" = num_pres,
                          "academicoTurmaFaltas" = num_faltas,
                          "academicoTurmaSituacao" = sit
                          where "academicoTurmaId" = pointerturma."academicoTurmaId";
               else
                   update "academicoTurma" set "academicoTurmaPresenca" = num_pres ,
                          "academicoTurmaFaltas" = num_faltas
                          where "academicoTurmaId" = pointerturma."academicoTurmaId";
               end if;
            else
                -- Se o numero total de presencas ou faltas real for maior que a carga horaria emitir alerta.
                if num_faltas_total > CargaHorariaTurma then
                   raise notice 'ALERTA fudeu numero de faltas + presenca maior que carga horaria total.';
                end if;
            end if;
            str_aux = NULL;
            num_pres_total := 0;
            faltas := 0;
            presencas := 0;
            situacao := 0;
        end loop;
    RETURN 1;
END;
$$;

alter function teste3(integer) owner to postgres;

