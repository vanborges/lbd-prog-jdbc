create view view_academico_nod(acd_rga, acd_nome, cur_cod, cur_nome) as
SELECT a."academicoRga"  AS acd_rga,
       a."academicoNome" AS acd_nome,
       c."cursoCodigo"   AS cur_cod,
       c."cursoNome"     AS cur_nome
FROM (academico a
         JOIN curso c ON ((a."cursoId" = c."cursoId")))
WHERE ((a."academicoSituacao" = 'I'::bpchar) AND (c."cursoCodigo" = ANY (ARRAY ['0107'::bpchar, '1101'::bpchar])))
ORDER BY (to_ascii((a."academicoNome")::text));

alter table view_academico_nod
    owner to postgres;

