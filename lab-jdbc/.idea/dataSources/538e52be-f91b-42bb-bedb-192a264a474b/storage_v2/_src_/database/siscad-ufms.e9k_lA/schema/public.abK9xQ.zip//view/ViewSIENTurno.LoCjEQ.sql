create view "ViewSIENTurno"(id, sigla, descricao) as
SELECT turno."turnoId"        AS id,
       turno."turnoSigla"     AS sigla,
       turno."turnoDescricao" AS descricao
FROM turno;

alter table "ViewSIENTurno"
    owner to postgres;

