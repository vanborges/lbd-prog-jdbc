create function academico_prova() returns trigger
    language plpgsql
as
$$
DECLARE pointer RECORD;
BEGIN
    
    FOR pointer IN  SELECT *
                    FROM "academicoTurma"
                    WHERE "turmaId" = NEW."turmaId" LOOP
    INSERT INTO nota("avaliacaoId", "academicoTurmaId", "notaValor")
             VALUES ( NEW."avaliacaoId", pointer."academicoTurmaId", null);

    END LOOP;
    
    RETURN NEW;
END;
$$;

alter function academico_prova() owner to postgres;

