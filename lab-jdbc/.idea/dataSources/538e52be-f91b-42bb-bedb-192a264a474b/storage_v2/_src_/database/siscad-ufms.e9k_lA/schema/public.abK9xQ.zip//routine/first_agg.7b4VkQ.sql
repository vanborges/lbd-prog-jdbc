create function first_agg(anyelement, anyelement) returns anyelement
    immutable
    strict
    language sql
as
$$
SELECT $1;
$$;

alter function first_agg(anyelement, anyelement) owner to postgres;

