create function avaliacao_exame() returns trigger
    language plpgsql
as
$$
DECLARE avalId INTEGER;
DECLARE ano INTEGER;
DECLARE modalidadeId INTEGER;
BEGIN

 /* Ao inserir qq tipo de avaliacao diferente de exame ...*/
select "turmaAno" into ano 
from turma  
where "turmaId"=NEW."turmaId";

select c."modalidadeId" into modalidadeId 
from turma t
join oferta o on t."ofertaId"=o."ofertaId"
join grade g on g."gradeId"=o."gradeId"
join curso c on c."cursoId"=g."cursoId"  
where t."turmaId"=NEW."turmaId"
limit 1;
        
IF ( (modalidadeId=1 and ano > 2010) or (modalidadeId=2 and ano >= 2011) )THEN
	return NEW;
END IF;
 
IF NEW."avaliacaoTipo" != 5 THEN
    /* Faz uma busca para verificar se já existe um avaliacao EXAME para turma */
    SELECT a."avaliacaoId" INTO avalId
    FROM "avaliacao" a
    WHERE a."avaliacaoTipo" = 5 AND  "turmaId" = NEW."turmaId" ;

    if avalId  IS NULL  then
       INSERT INTO avaliacao("turmaId", "avaliacaoSigla", "avaliacaoDescricao",
                             "avaliacaoTipo" ) VALUES (NEW."turmaId", 'EX', 'EXAME',5);
    end if;
  END IF;
  

   RETURN NEW;
END;
$$;

alter function avaliacao_exame() owner to postgres;

