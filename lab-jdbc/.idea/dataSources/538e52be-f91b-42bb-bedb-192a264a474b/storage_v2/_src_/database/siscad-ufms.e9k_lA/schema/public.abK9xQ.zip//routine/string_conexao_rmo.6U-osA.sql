create function string_conexao_rmo() returns text
    language plpgsql
as
$$
    -- devolve uma string de conexao com o banco do rmo/grh para 
	-- realizar a leitura de dados via dblink.
DECLARE
	con_host  varchar ; -- maquina/servidor do banco
	con_port varchar; -- porta 
	con_db varchar; -- nome do banco
	con_user varchar; -- nome do usuario
	con_senha varchar ; -- senha do usuario
	
BEGIN
	 
	con_host:= 'pgdb.ufms.br';
	con_port:= '5432';
	con_db= 'ufms';
	con_user:= 'bd_ufms_importacao';
	con_senha:= 'dus5e0@';

	RETURN ' dbname=' || con_db || ' port='||con_port||' user='||con_user ||' host='|| con_host ||' password='||con_senha ;
	
	
END;
$$;

alter function string_conexao_rmo() owner to postgres;

