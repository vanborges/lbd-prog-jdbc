create view view_bolsas_acompanhamento(academico_rga, academico_nome, academico_cpf, centro_sigla, centro_nome,
                                       curso_codigo, curso_nome, semestres_minimo, semestres_cursados,
                                       academico_percentual_carga_horaria_cursada, total_mat, total_rep,
                                       academico_coeficiente_rendimento, academico_fone, academico_celular, ano,
                                       semestre, tipo_ingresso, academico_email, academico_situacao) as
SELECT a."academicoRga"                                                                       AS academico_rga,
       a."academicoNome"                                                                      AS academico_nome,
       a."academicoCpf"                                                                       AS academico_cpf,
       ce."centroSigla"                                                                       AS centro_sigla,
       ce."centroNome"                                                                        AS centro_nome,
       cu."cursoCodigo"                                                                       AS curso_codigo,
       cu."cursoNome"                                                                         AS curso_nome,
       cu."cursoDuracaoMin"                                                                   AS semestres_minimo,
       o."ocorrenciaSerie"                                                                    AS semestres_cursados,
       ma."academicoPercentualCargaHorariaCursada"                                            AS academico_percentual_carga_horaria_cursada,
       mat.total_mat,
       rep.total_rep,
       ma."academicoCoeficienteRendimento"                                                    AS academico_coeficiente_rendimento,
       a."academicoFone"                                                                      AS academico_fone,
       a."academicoCelular"                                                                   AS academico_celular,
       date_part('year'::text, (now() - '6 mons'::interval))                                  AS ano,
       ceil((date_part('month'::text, (now() - '6 mons'::interval)) / (6)::double precision)) AS semestre,
       ing."tipoIngresso"                                                                     AS tipo_ingresso,
       a."academicoEmail"                                                                     AS academico_email,
       a."academicoSituacao"                                                                  AS academico_situacao
FROM ((((((((centro ce
    JOIN curso cu ON ((ce."centroId" = cu."centroId")))
    JOIN academico a ON ((cu."cursoId" = a."cursoId")))
    LEFT JOIN "matriculaAcademico" ma ON ((a."academicoId" = ma."academicoId")))
    JOIN ocorrencia o ON ((a."academicoId" = o."academicoId")))
    JOIN (SELECT o_1."academicoId",
                 max(o_1."ocorrenciaSequencia") AS seq
          FROM ocorrencia o_1
          GROUP BY o_1."academicoId") maxocor ON (((o."academicoId" = maxocor."academicoId") AND
                                                   (o."ocorrenciaSequencia" = maxocor.seq))))
    LEFT JOIN (SELECT t."academicoId",
                      count(*) AS total_mat
               FROM "academicoTurma" t
               WHERE ((t."academicoTurmaPregSituacao" <> ALL (ARRAY ['DS'::bpchar, 'DC'::bpchar])) AND
                      ((t."ANO")::double precision = date_part('year'::text, (now() - '6 mons'::interval))) AND
                      ((t."SEM")::double precision =
                       ceil((date_part('month'::text, (now() - '6 mons'::interval)) / (6)::double precision))))
               GROUP BY t."academicoId") mat ON ((o."academicoId" = mat."academicoId")))
    LEFT JOIN (SELECT t."academicoId",
                      count(*) AS total_rep
               FROM "academicoTurma" t
               WHERE ((t."academicoTurmaBloqueioMF" = (1)::smallint) AND
                      (t."academicoTurmaPregSituacao" = ANY (ARRAY ['RN'::bpchar, 'RF'::bpchar, 'RP'::bpchar])) AND
                      ((t."ANO")::double precision = date_part('year'::text, (now() - '6 mons'::interval))) AND
                      ((t."SEM")::double precision =
                       ceil((date_part('month'::text, (now() - '6 mons'::interval)) / (6)::double precision))))
               GROUP BY t."academicoId") rep ON ((o."academicoId" = rep."academicoId")))
         LEFT JOIN (SELECT o_1."academicoId",
                           (((ts."tipoSituacaoSigla")::text || ' - '::text) ||
                            (ts."tipoSituacaoNome")::text) AS "tipoIngresso"
                    FROM (ocorrencia o_1
                             JOIN "tipoSituacao" ts ON ((o_1."tipoSituacaoId" = ts."tipoSituacaoId")))
                    WHERE (ts."tipoSituacaoTipo" = 'ING'::bpchar)) ing ON ((o."academicoId" = ing."academicoId")));

alter table view_bolsas_acompanhamento
    owner to postgres;

