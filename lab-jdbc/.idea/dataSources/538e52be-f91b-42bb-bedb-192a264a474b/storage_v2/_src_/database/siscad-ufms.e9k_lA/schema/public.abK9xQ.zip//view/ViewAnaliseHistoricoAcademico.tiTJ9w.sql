create view "ViewAnaliseHistoricoAcademico"("ViewAnaliseHistoricoAcademicoId", "ViewAnaliseHistoricoAcademicoRga",
                                            "ViewAnaliseHistoricoAcademicoNome",
                                            "ViewAnaliseHistoricoAcademicoSituacao",
                                            "ViewAnaliseHistoricoAcademicoCursoCodigo",
                                            "ViewAnaliseHistoricoAcademicoCursoNome",
                                            "ViewAnaliseHistoricoAcademicoUsrId",
                                            "ViewAnaliseHistoricoAcademicoData") as
SELECT a."academicoId"                                              AS "ViewAnaliseHistoricoAcademicoId",
       a."academicoRga"                                             AS "ViewAnaliseHistoricoAcademicoRga",
       a."academicoNome"                                            AS "ViewAnaliseHistoricoAcademicoNome",
       a."academicoSituacao"                                        AS "ViewAnaliseHistoricoAcademicoSituacao",
       c."cursoCodigo"                                              AS "ViewAnaliseHistoricoAcademicoCursoCodigo",
       c."cursoNome"                                                AS "ViewAnaliseHistoricoAcademicoCursoNome",
       ah."usrId"                                                   AS "ViewAnaliseHistoricoAcademicoUsrId",
       to_char(ah."analsieHistoricoUpdateDate", 'DD/MM/YYYY'::text) AS "ViewAnaliseHistoricoAcademicoData"
FROM ((curso c
    JOIN academico a ON ((c."cursoId" = a."cursoId")))
         LEFT JOIN "analiseHistorico" ah ON ((a."academicoId" = ah."academicoId")))
ORDER BY ah."analsieHistoricoUpdateDate" DESC, (to_ascii((a."academicoNome")::text));

alter table "ViewAnaliseHistoricoAcademico"
    owner to postgres;

