create view "ViewSecretariaCentro"("ViewSecretariaCentroId", "ViewSecretariaCentroSecretariaId",
                                   "ViewSecretariaCentroDepartamentoId", "ViewSecretariaCentroDepartamentoSigla",
                                   "ViewSecretariaCentroDepartamentoNome", "ViewSecretariaCentroOfertaId",
                                   "foreignId") as
    SELECT o."ofertaId"           AS "ViewSecretariaCentroId",
           se."secretariaId"      AS "ViewSecretariaCentroSecretariaId",
           de."departamentoId"    AS "ViewSecretariaCentroDepartamentoId",
           de."departamentoSigla" AS "ViewSecretariaCentroDepartamentoSigla",
           de."departamentoNome"  AS "ViewSecretariaCentroDepartamentoNome",
           o."ofertaId"           AS "ViewSecretariaCentroOfertaId",
           se."secretariaId"      AS "foreignId"
    FROM (((((oferta o
        JOIN grade g ON ((o."gradeId" = g."gradeId")))
        JOIN disciplina di ON ((g."disciplinaId" = di."disciplinaId")))
        JOIN departamento de ON ((di."departamentoId" = de."departamentoId")))
        JOIN "secretariaCentro" sd ON ((de."centroId" = sd."centroId")))
             JOIN secretaria se ON ((sd."secretariaId" = se."secretariaId")))
    WHERE ((se."secretariaActive" IS TRUE) AND (sd."secretariaCentroActive" IS TRUE))
    UNION
    SELECT o."ofertaId"           AS "ViewSecretariaCentroId",
           u."foreignId"          AS "ViewSecretariaCentroSecretariaId",
           de."departamentoId"    AS "ViewSecretariaCentroDepartamentoId",
           de."departamentoSigla" AS "ViewSecretariaCentroDepartamentoSigla",
           de."departamentoNome"  AS "ViewSecretariaCentroDepartamentoNome",
           o."ofertaId"           AS "ViewSecretariaCentroOfertaId",
           u."foreignId"
    FROM (((((oferta o
        JOIN grade g ON ((o."gradeId" = g."gradeId")))
        JOIN disciplina di ON ((g."disciplinaId" = di."disciplinaId")))
        JOIN departamento de ON ((di."departamentoId" = de."departamentoId")))
        JOIN "coordenadorCoac" cc ON ((de."centroId" = cc."centroId")))
             JOIN usr u ON ((cc."usrId" = u."usrId")))
    WHERE (cc."coordenadorCoacSituacao" IS TRUE);

alter table "ViewSecretariaCentro"
    owner to postgres;

