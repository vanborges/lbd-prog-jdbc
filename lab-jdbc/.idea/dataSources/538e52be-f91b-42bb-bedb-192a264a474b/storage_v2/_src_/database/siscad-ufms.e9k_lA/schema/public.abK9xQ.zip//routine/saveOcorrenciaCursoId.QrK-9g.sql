create function "saveOcorrenciaCursoId"() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW."cursoId" := (select "cursoId" from academico where "academicoId" = NEW."academicoId");
  RETURN NEW;
exception
	when OTHERS then
	    RETURN NEW;  
END;
$$;

alter function "saveOcorrenciaCursoId"() owner to postgres;

