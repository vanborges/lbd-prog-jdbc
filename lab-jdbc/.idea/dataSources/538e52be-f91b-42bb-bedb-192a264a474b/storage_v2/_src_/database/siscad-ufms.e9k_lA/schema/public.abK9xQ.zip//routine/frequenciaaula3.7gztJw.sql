create function frequenciaaula3(integer, integer, integer, date, date, character, integer, real, integer) returns integer
    language plpgsql
as
$$
DECLARE
    turmaId ALIAS FOR $1;
    diaLetivoId ALIAS FOR $2;
    academicoTurmaId ALIAS FOR $3;
    dt_ini ALIAS FOR $4;
    dt_fim ALIAS FOR $5;
    freq ALIAS FOR $6;
    opt ALIAS FOR $7;
    carga_horaria_total ALIAS FOR $8;
    log_id ALIAS FOR $9;
    --carga_horaria_total float4; -- integer;
    pointer RECORD;
    ch integer;
    ch_total integer;
    str bit(2)[];
    str_aux bit(2)[];
    vet_aux bit(2)[];
    varaux bit(2);
    num_faltas integer;
    num_pres integer;
    acdTurmaId integer;
    num_pres_atual integer;
    num_faltas_atual integer;
    sit char(2);
    sit_antiga char(2);
    num_faltas_aux integer;
    num_pres_aux integer;
    carga_horaria_fornecida real;
    first bool; /* variavel de controle */
    i smallint; /* contador */
    sql text; /* armazena o sql para a consulta */
    perc real;
    turmaPai integer; /* Guarda, se houver, a turmaPai da turma atual */
    pointerFather RECORD;
    tam_vet_aux integer;
    tam_str_aux integer;
    logText text;
    situacao char(2);
    auxiliar text;
BEGIN
	tam_str_aux := 0;
    logText := '@ACADEMICOTURMA_FREQporAULA_BD[turmaId:' || turmaId || ', opt='|| opt ||'][(academicoTurmaId,frequenciaValor,diaLetivoId)[academicoTurmaId, academicoTurmaSituacao, academicoTurmaFaltas,academicoTurmaPresenca]';
	FOR pointerFather IN
		SELECT "turmaPai"
		FROM turma
		WHERE "turmaId" = turmaId
	LOOP
		turmaPai := pointerFather."turmaPai";
	END LOOP;
/*
	Observação: a consulta usada para listar os academicos para serem
	lançacas presenças/ausencias supoe que academicos RN não tenha nehum
	registro na tabela frequencia.
	*/
    if opt = 1 then
		IF nullvalue(turmaPai) THEN
			sql := ' and d."turmaId" = ' || turmaId;
		ELSE
  			sql := ' and d."turmaId" in (' || turmaId || ',' || turmaPai || ') ' ||
                   ' and a."academicoTurmaId" in (select "academicoTurmaId" from "academicoTurma" where "turmaId"= ' || turmaId || ') '; 
		END IF;
	elseif opt = 4 then
        IF nullvalue(turmaPai) THEN
            sql := ' and d."turmaId" = ' || turmaId ||
                   ' and a."academicoTurmaId" = ' || academicoTurmaId ;
        ELSE
            sql := ' and d."turmaId" in (' || turmaId || ',' || turmaPai || ')' ||
                   ' and a."academicoTurmaId" = ' || academicoTurmaId ;
        END IF;
    elseif opt = 2 then
        IF nullvalue(turmaPai) THEN
            sql := 'and d."turmaId" = ' || turmaId || ' and d."diaLetivoId" = ' || diaLetivoId;
        ELSE
            sql := 'and d."turmaId" in (' || turmaId || ',' || turmaPai || ') and d."diaLetivoId" = ' || diaLetivoId ||
	               ' and a."academicoTurmaId" in (select "academicoTurmaId" from "academicoTurma" where "turmaId"= ' || turmaId || ') ';

        END IF;
    elseif opt = 5 then
        sql := ' and a."academicoTurmaId" = ' || academicoTurmaId ||
               ' and d."diaLetivoId"      = ' || diaLetivoId;
    elseif opt = 3 then
           IF nullvalue(turmaPai) THEN
              sql := ' and d."turmaId" = ' || turmaId || '
                       and d."diaLetivoData" >= '''   || dt_ini  ||
                   ''' and d."diaLetivoData" <= ''' || dt_fim  || '''';
           ELSE
              sql := ' and d."turmaId" in (' || turmaId || ',' || turmaPai || ') ' ||
                      ' and a."academicoTurmaId" in (select "academicoTurmaId" from "academicoTurma" where "turmaId"= ' || turmaId || ')' || 
                     '  and d."diaLetivoData" >= '''   || dt_ini  ||
                   ''' and d."diaLetivoData" <= ''' || dt_fim  || '''';

           END IF;
    elseif opt = 6 then
        sql := ' and a."academicoTurmaId" = '  || academicoTurmaId ||
               ' and d."diaLetivoData" >= '''  || dt_ini           ||
               ''' and d."diaLetivoData" <= '''|| dt_fim           ||'''';
    end if;

    sql := 'select a."academicoTurmaId", d."diaLetivoId",d."diaLetivoCargaHorariaDia",
                    a."academicoTurmaFaltas" ,a."academicoTurmaPresenca",
                    NULL::bit [] AS "frequenciaValor", 0 as aux, a."academicoTurmaSituacao",
                    a."academicoTurmaBloqueioMF"
            FROM "diaLetivo" d
                 JOIN turma t on (d."turmaId" = t."turmaId" OR d."turmaId" = t."turmaPai")
                 JOIN "academicoTurma" a on t."turmaId" = a."turmaId"
            where ( (a."academicoTurmaTipoDependencia"!=''RN'' or a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) ' || sql || '
			EXCEPT
			select a."academicoTurmaId", d."diaLetivoId",d."diaLetivoCargaHorariaDia",
                a."academicoTurmaFaltas" ,a."academicoTurmaPresenca",
                NULL::bit [] AS "frequenciaValor", 0 as aux, a."academicoTurmaSituacao",a."academicoTurmaBloqueioMF"
			from "diaLetivo" d
                join frequencia f       using ("diaLetivoId")
                join "academicoTurma" a using ("academicoTurmaId")
			where ( (a."academicoTurmaTipoDependencia"!=''RN'' or
a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) '|| sql ||'
			UNION
			select a."academicoTurmaId", d."diaLetivoId",d."diaLetivoCargaHorariaDia",
                    a."academicoTurmaFaltas" ,a."academicoTurmaPresenca",f."frequenciaValor" AS "frequenciaValor",1 as aux, a."academicoTurmaSituacao",a."academicoTurmaBloqueioMF"
			from "diaLetivo" d
                join frequencia f       using ("diaLetivoId")
                join "academicoTurma" a using ("academicoTurmaId")
			where ((a."academicoTurmaTipoDependencia"!=''RN'' or a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) ' || sql ;

    /*Inicializando*/
    num_faltas:=0;
    num_faltas_atual:=0;
    num_pres_atual:=0;
    num_pres:=0;
    sit=' ';

    /*Inserindo o primeiro valor no vetor de bits*/
    IF freq='P' OR  freq='p' THEN
        str_aux := ARRAY['10'];
        varaux := B'10';
    ELSEIF freq='F' OR freq='f' THEN
        str_aux := ARRAY['01'];
        varaux := B'01';
    ELSE
        str_aux := ARRAY['00'];
        varaux := B'00';
    END IF;
    acdTurmaId:=NULL;

     /*TODOS<->TODAS AULAS*/
    IF opt=1 THEN
		select sum(d."diaLetivoCargaHorariaDia") into carga_horaria_fornecida
        from "diaLetivo" d
        where d."turmaId" in (turmaId, turmaPai);

        IF freq='P' OR freq='p' THEN
           num_pres:=carga_horaria_fornecida;
		   num_faltas:=0;
           perc:=0;
        ELSEIF freq='F' OR freq='f' THEN
				num_faltas:=carga_horaria_fornecida;
				num_pres:=0;
				sit='RF';
				perc:=100;
			ELSE
				num_faltas:=0;
				num_pres:=0;
                perc:=0;
		END IF;

-- RAISE NOTICE '%',sql;
			FOR pointer IN EXECUTE( sql )  LOOP
              /*Atualizando o número de Faltas,Presenças do acadêmico além da sua situação*/

              IF nullvalue(acdTurmaId) THEN /*Primeiro Acadêmico*/
                acdTurmaId:=pointer."academicoTurmaId";
                sit:=pointer."academicoTurmaSituacao";

                if (perc>25) then
				    sit='RF';
			    else
			        if (sit='RF') then
					   sit=' ';	
                    end if;
                end if;			
                update "academicoTurma" set "academicoTurmaFaltas"=num_faltas ,
					"academicoTurmaPresenca"=num_pres,"academicoTurmaSituacao"=sit
					where "academicoTurma"."academicoTurmaId"=acdTurmaId;
                    situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
                logText := logText || '[up1:' || acdTurmaId || ',' || situacao || ',' || num_faltas || ',' || num_pres || ']';
				ELSEIF(acdTurmaId!=pointer."academicoTurmaId") THEN
					acdTurmaId:=pointer."academicoTurmaId";
					sit:=pointer."academicoTurmaSituacao";
					if (perc>25) then
						sit='RF';
					else
						if (sit='RF') then
							sit=' ';	
						end if;
					end if;			
                update "academicoTurma" set "academicoTurmaFaltas"=num_faltas ,
					"academicoTurmaPresenca"=num_pres,"academicoTurmaSituacao"=sit
        		where	"academicoTurma"."academicoTurmaId"=acdTurmaId;
                     situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
                logText := logText || '[up2:' || acdTurmaId || ',' || situacao || ',' || num_faltas || ',' || num_pres || ']';
              ELSE
              END IF;

              /*Carga Horaria Do Dia*/
              ch:=ceil(pointer."diaLetivoCargaHorariaDia");
              str = NULL;
              auxiliar = '';
              IF ch>0 THEN              
                 str = str_aux;
                 auxiliar = varaux;
                  /*Criando Vetor de Frequencia*/
                  FOR i IN 1..ch-1 LOOP
                     str := array_append(str,varaux);
                     auxiliar := (auxiliar || ',' || varaux);
                  END LOOP;
              END IF;

              /*Verifica se eh INSERT ou UPDATE*/
              IF pointer."aux"=1 THEN /*UPDATE*/
                 update "frequencia" set "frequenciaValor"=str where
					 "frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and
					"frequencia"."diaLetivoId"=pointer."diaLetivoId";
                  logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';
              ELSE
                 insert into "frequencia"
					("academicoTurmaId","diaLetivoId","frequenciaValor") values
					(pointer."academicoTurmaId",pointer."diaLetivoId",str);
                  logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId"||')';
              END IF;
          END LOOP;

   /*TODOS <-> AULA SELECIONADA OU UM <-> AULA SELECIONADA*/
   ELSEIF opt=2 or opt=5 THEN

	first := false; /* p/ marcar o codigo que deve ser executado somente uma vez.*/
	FOR pointer IN EXECUTE( sql )  LOOP
		IF  first = FALSE  THEN /* Este codigo e para ser executado uma vez ("desempenho")*/
			first := true;
			/*Carga Horaria Do Dia*/
			ch:=ceil(pointer."diaLetivoCargaHorariaDia");
			str = NULL;
            auxiliar = '';
			IF ch>0 THEN
				str = str_aux;
                auxiliar = varaux;
				/*Criando Vetor de FrequenciaAux*/
				FOR i IN 1..ch-1 LOOP
					str := array_append(str,varaux);
                    auxiliar := (auxiliar || ',' || varaux);
				END LOOP;
			END IF;
		END IF;

		/*Verifica se eh INSERT ou UPDATE*/
		IF pointer."aux"=1 THEN /*UPDATE*/
			update "frequencia" set "frequenciaValor"=str 
			where "frequencia"."academicoTurmaId"=pointer."academicoTurmaId" 
			and "frequencia"."diaLetivoId"=pointer."diaLetivoId";
            logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';
		ELSE
			insert into "frequencia" ("academicoTurmaId","diaLetivoId","frequenciaValor") 
			values (pointer."academicoTurmaId",pointer."diaLetivoId",str);
                  logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId"|| ')';
		END IF;

          /* Vetor auxiliar para se deslocar no registro de frequencia */
          str_aux := pointer."frequenciaValor";

          /* Atribui uma flag p/ sinalizar o fim do vetor */
          str_aux := array_append(str_aux,B'11');
          i := 1; /* o vetor começa na posição um */

          /* Iniciando as variaveis */
          num_faltas := 0;
          num_pres   := 0;

          --RAISE NOTICE '%',str_aux;
          /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
		  
		  -- pega o tamanho do vetor
		  tam_str_aux := replace(split_part(array_dims(str_aux),':',2),']','')::int;
		  -- RAISE NOTICE '%',tam_str_aux;
		  --Codigo antigo
          -- WHILE str_aux[i] != B'11' LOOP

			WHILE i < tam_str_aux LOOP
             if(str_aux[i] = B'01') then /* se falta */
                num_faltas:=num_faltas+1;
             elseif (str_aux[i] = B'10') then /* se presença */
                num_pres:=num_pres+1;
             elseif (str_aux[i] = B'00') then

             end if;
             i := i + 1;
          END LOOP;



          /*
           * Atualizando o número de F/P e a Situação do acadêmico:
           * As presencas/faltas do dia letivo em questao sao decrementadas
           * antes de ser feita a alteracao nos mesmos.
           * Alteracao: Thiago A. Amaral em 01/10/2008
           */
          
          /* Garante que o num_faltas_atual não será null e nem menor que 0 */
          IF nullvalue(pointer."academicoTurmaFaltas") 
          		OR pointer."academicoTurmaFaltas" < num_faltas THEN
          	num_faltas_atual := 0;
          ELSE
          	num_faltas_atual := pointer."academicoTurmaFaltas" - num_faltas;
          END IF;
          
          /* Garante que o num_pres_atual não será null e nem menor que 0 */
          IF nullvalue(pointer."academicoTurmaPresenca")
          		OR pointer."academicoTurmaPresenca" < num_pres THEN
    	      num_pres_atual   := 0;
          ELSE
	          num_pres_atual   := pointer."academicoTurmaPresenca" - num_pres;
          END IF;
--RAISE NOTICE '%',num_faltas_atual;
--RAISE NOTICE '%',num_pres_atual;


          /* Se houve alteração no nº de faltas e/ou presença fazer update */
             if varaux = B'01' then
                num_faltas_atual := num_faltas_atual + ch;
             elseif varaux = B'10' then
                num_pres_atual := num_pres_atual + ch;
             end if;
--RAISE NOTICE '%',num_faltas_atual;
             if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
                sit := 'RF';
                update "academicoTurma" set
                    "academicoTurmaFaltas"=num_faltas_atual ,
                    "academicoTurmaPresenca"=num_pres_atual,
                    "academicoTurmaSituacao"=sit where
"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
                    situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
			logText := logText || '[up3:'|| pointer."academicoTurmaId" || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
             else
                sit:=pointer."academicoTurmaSituacao";

                if (sit='RF') then
				   sit=' ';	
                end if;

                 update "academicoTurma" set
                    "academicoTurmaFaltas"=num_faltas_atual ,
                    "academicoTurmaPresenca"=num_pres_atual,
                    "academicoTurmaSituacao"=sit where
					"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
                                        situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
                 logText := logText || '[up4:' ||  pointer."academicoTurmaId" || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
             end if;
      END LOOP;

   /*TODOS <-> INTERVALO DE AULA  OU UM <-> INTERVALO DE AULA*/
   ELSEIF opt = 3 or opt = 6 THEN
      ch_total   := 0;
      acdTurmaId := 0;
      num_faltas := 0;
      num_pres   := 0;
      vet_aux    := ARRAY['00'];

      FOR pointer IN EXECUTE( sql )  LOOP
          /*Carga Horaria Do Dia*/
          ch:=ceil(pointer."diaLetivoCargaHorariaDia");

          str = NULL;
          auxiliar = '';
          IF ch>0 THEN
             str = str_aux;
             auxiliar = varaux;
             /*Criando Vetor de FrequenciaAux*/
             FOR i IN 1..ch-1 LOOP
                 str := array_append(str,varaux);
                auxiliar := (auxiliar || ',' || varaux);
             END LOOP;
          END IF;

          /*Verifica se eh INSERT ou UPDATE*/
          IF pointer."aux"=1 THEN /*UPDATE*/
             update "frequencia" set "frequenciaValor"=str where
             "frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and
             "frequencia"."diaLetivoId"=pointer."diaLetivoId";
			logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';
          ELSE
              insert into "frequencia" ("academicoTurmaId","diaLetivoId","frequenciaValor") 
					values(pointer."academicoTurmaId",pointer."diaLetivoId",str);
            logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';

          END IF;

          if (acdTurmaId != 0) AND (acdTurmaId != pointer."academicoTurmaId") then
          
            /*Mudou o acadêmico*/
            /* Atribui uma flag p/ sinalizar o fim do vetor */
            vet_aux := array_append(vet_aux,B'11');
            i := 1; /* o vetor começa na posição um */
             
            /* Iniciando as variaveis */
            num_faltas := 0;
            num_pres   := 0;
             
			-- pega o tamanho do vetor
			tam_vet_aux := replace(split_part(array_dims(vet_aux),':',2),']','')::int;
-- RAISE NOTICE 'vet_aux %',vet_aux;
			--Codigo antigo
			-- WHILE str_aux[i] != B'11' LOOP
-- RAISE NOTICE 'tam_vet_aux %',tam_vet_aux;
			/*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
			WHILE i < tam_vet_aux LOOP
                if(vet_aux[i] = B'01') then
                   num_faltas:=num_faltas+1;
                elseif (vet_aux[i] = B'10') then
                   num_pres:=num_pres+1;
                end if;
                i := i + 1;
             END LOOP;

          	num_faltas_atual := num_faltas_atual - num_faltas;
	        num_pres_atual   := num_pres_atual - num_pres;

/*
RAISE NOTICE 'num_faltas_atual %',num_faltas_atual;
RAISE NOTICE 'num_pres_atual %',num_pres_atual;
RAISE NOTICE ' ch_total %', ch_total;
RAISE NOTICE 'varaux %',varaux;
*/
             /* Se houve alteração no nº de faltas e/ou presença fazer update */
             if varaux = B'01' then
                num_faltas_atual := num_faltas_atual + ch_total;
             elseif varaux = B'10' then
                num_pres_atual := num_pres_atual + ch_total;
             end if;

             if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
               sit := 'RF';
               update "academicoTurma" set
               "academicoTurmaFaltas"=num_faltas_atual ,
               "academicoTurmaPresenca"=num_pres_atual,
               "academicoTurmaSituacao"=sit 
               where "academicoTurma"."academicoTurmaId"= acdTurmaId;
                                   situacao = sit;
                    IF nullvalue(sit) then
                      situacao = '';
                    end if;
               logText := logText || '[up5:' || acdTurmaId || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
             else
                sit:=pointer."academicoTurmaSituacao";

			    if (sit='RF') then
				  sit=' ';
                end if;


              update "academicoTurma" set
              "academicoTurmaFaltas"=num_faltas_atual ,
              "academicoTurmaPresenca"=num_pres_atual,
              "academicoTurmaSituacao"=sit where
              "academicoTurma"."academicoTurmaId"= acdTurmaId;
                                  situacao = sit;
                    IF nullvalue(sit) then
                      situacao = '';
                    end if;
              logText := logText || '[up6:'|| acdTurmaId || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
            end if;
            vet_aux  := ARRAY['00'];
            ch_total := 0;
          end if;

          /* Vetor auxiliar para se deslocar no vetor de  frequencia de todos os dias*/

          /* para evitar concatenar com nulo */
          if not nullvalue(pointer."frequenciaValor") then
             vet_aux := array_cat(vet_aux,pointer."frequenciaValor");
          end if;
          ch_total := ch_total + ch;
          num_faltas_atual := pointer."academicoTurmaFaltas";
          num_pres_atual   := pointer."academicoTurmaPresenca";
          acdTurmaId := pointer."academicoTurmaId";

      END LOOP;
      
      -- Usado para o ultimo academico, fora do loop
      if not nullvalue(acdTurmaId) then
         /* Atribui uma flag p/ sinalizar o fim do vetor */
         vet_aux := array_append(vet_aux,B'11');
         i := 1; /* o vetor começa na posição um */
         /* Iniciando as variaveis */
         num_faltas := 0;
         num_pres   := 0;
         --num_faltas_atual:=0;
         --num_pres_atual:=0;
         
         
		-- pega o tamanho do vetor
		tam_str_aux := replace(split_part(array_dims(vet_aux),':',2),']','')::int;
		-- RAISE NOTICE '%',tam_str_aux;
		--Codigo antigo
		-- WHILE str_aux[i] != B'11' LOOP

		/*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
		WHILE i < tam_str_aux LOOP
            if(vet_aux[i] = B'01') then
               num_faltas:=num_faltas+1;
            elseif (vet_aux[i] = B'10') then
               num_pres:=num_pres+1;
            end if;
            i := i + 1;
         END LOOP;
-- RAISE NOTICE 'num_faltas %',num_faltas;
-- RAISE NOTICE 'num_pres %',num_pres;
         /*Atualizando o número de F/P e a Situação do acadêmico*/
          num_faltas_atual := num_faltas_atual - num_faltas;
          num_pres_atual   := num_pres_atual - num_pres;

         /* Se houve alteração no nº de faltas e/ou presença fazer update*/
         if varaux = B'01' then
            num_faltas_atual := num_faltas_atual + ch_total;
         elseif varaux = B'10' then
            num_pres_atual := num_pres_atual + ch_total;
         end if;
         
         if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
            sit := 'RF';
            update "academicoTurma" set
            "academicoTurmaFaltas"=num_faltas_atual,
            "academicoTurmaPresenca"=num_pres_atual,
            "academicoTurmaSituacao"=sit 
			where "academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
                                situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
            logText := logText || '[up7:' ||pointer."academicoTurmaId" || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
         else
             sit:=pointer."academicoTurmaSituacao";
	          if (sit='RF') then
			     sit=' ';
              end if;

            update "academicoTurma" set
              "academicoTurmaFaltas"=num_faltas_atual,
              "academicoTurmaPresenca"=num_pres_atual,
              "academicoTurmaSituacao"=sit 
			  where "academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
                                  situacao = sit;
                    IF nullvalue( sit) then
                      situacao = '';
                    end if;
              logText := logText || '[up8:' || pointer."academicoTurmaId" || ',' || situacao || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
         end if;
      end if;

   /*UM <-> TODAS AS AULAS*/
   ELSEIF opt=4 THEN
      /* FOR pointer IN
          select f."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",1 as aux
          from "diaLetivo" d join "frequencia" f
               on d."diaLetivoId"=f."diaLetivoId"
          where d."turmaId" in ( turmaId, turmaPai ) and f."academicoTurmaId"=academicoTurmaId
          union
          select a."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",0 as aux
          from "diaLetivo" d join "academicoTurma" a
               on d."turmaId"=a."turmaId"
          where d."turmaId" in ( turmaId, turmaPai ) and
				(a."academicoTurmaTipoDependencia"!='RN' or
				a."academicoTurmaTipoDependencia" is null) and
				a."academicoTurmaId"=academicoTurmaId
          EXCEPT
          select f."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",0 as aux
          from "diaLetivo" d join "frequencia" f
                on d."diaLetivoId"=f."diaLetivoId"
          where d."turmaId" in ( turmaId, turmaPai ) and f."academicoTurmaId"=academicoTurmaId
          LOOP */
          FOR pointer IN EXECUTE( sql )  LOOP
              /*Carga Horaria Do Dia*/
              ch:=ceil(pointer."diaLetivoCargaHorariaDia");
              acdTurmaId:=pointer."academicoTurmaId";
              str = NULL;
              auxiliar = '';
              IF ch>0 THEN
                 str = str_aux;
                 auxiliar = varaux;
              END IF;
              /*Criando Vetor de Frequencia*/
              FOR i IN 1..ch-1 LOOP
                 str := array_append(str,varaux);
                 auxiliar := (auxiliar || ',' || varaux);
              END LOOP;

              /*Verifica se eh INSERT ou UPDATE*/
              IF pointer."aux"=1 THEN /*UPDATE*/
                 update "frequencia" set "frequenciaValor"=str
				 where "frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and "frequencia"."diaLetivoId"=pointer."diaLetivoId";                                                  
                 logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';
              ELSE
                 insert into "frequencia"("academicoTurmaId","diaLetivoId","frequenciaValor") values
										(pointer."academicoTurmaId",pointer."diaLetivoId",str);
                 logText:= logText || '(' || pointer."academicoTurmaId" ||',{' || auxiliar ||  '},' || pointer."diaLetivoId" || ')';
              END IF;
          END LOOP;
          /* Se houve alteração no nº de faltas e/ou presença fazer update */
          sit := '';

--corrigido
        select sum(d."diaLetivoCargaHorariaDia") into carga_horaria_fornecida
        from "diaLetivo" d
        where d."turmaId" in (turmaId, turmaPai);

          if varaux = B'01' then
            num_faltas_atual := carga_horaria_fornecida;
			num_pres_atual	 := 0;
            perc:=100;
            sit := 'RF';
          elseif varaux = B'10' then
            num_pres_atual 	 := carga_horaria_fornecida;
			num_faltas_atual := 0;
            perc:=0;
          else
				num_faltas_atual := 0;
				num_pres_atual   := 0;
                perc:=0;
          end if;
          /*Atualizando o número de Faltas,Presenças do acadêmico além da sua situação*/

        IF not nullvalue(acdTurmaId) THEN /*Primeiro Acadêmico*/
            select at."academicoTurmaSituacao" into sit
            from "academicoTurma" at
            where at."academicoTurmaId" =acdTurmaId;
			
            if (perc>25) then
			    sit='RF';
		    else
		        if (sit='RF') then
				   sit=' ';
                end if;
            end if;

				update "academicoTurma" set "academicoTurmaFaltas"=num_faltas_atual ,
					"academicoTurmaPresenca"=num_pres_atual,"academicoTurmaSituacao"=sit
					where "academicoTurma"."academicoTurmaId"=acdTurmaId;
                    situacao = sit;
                    IF  nullvalue(sit) then
                      situacao = '';
                    end if;
                    
                    logText := logText || '[up9:' || acdTurmaId || ',' || situacao  || ',' || num_faltas_atual || ',' || num_pres_atual || ']';
		END IF;
	END IF;
           logText := logText || ']ACADEMICOTURMA_FREQporAULA_BD@';
           UPDATE "systemLog"
            SET "systemLogInfo" = "systemLogInfo" ||  logText
            WHERE "systemLogId"=log_id;

	RETURN 1;
END;
$$;

alter function frequenciaaula3(integer, integer, integer, date, date, char, integer, real, integer) owner to postgres;

