create function carga_horaria2("turmaId" integer) returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE
 turmaId ALIAS FOR $1;
 DisciplinaId INTEGER;
 Carga INTEGER;
BEGIN
     IF(turmaId is not null)THEN
         select into DisciplinaId d."disciplinaId"
         from disciplina d 
         join grade g on g."disciplinaId"=d."disciplinaId"
         join oferta o on o."gradeId"=g."gradeId"
         join turma t on t."ofertaId"=o."ofertaId"
         where t."turmaId"=turmaId;

        select INTO Carga d."disciplinaCarga"
        from disciplina d
             where d."disciplinaId"= DisciplinaId;
             
    end if;
    return Carga;
END;
$$;

alter function carga_horaria2(integer) owner to postgres;

