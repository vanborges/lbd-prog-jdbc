create view vprojeto5(projnome, projnumero, projlocal, dnum) as
SELECT projeto.projnome,
       projeto.projnumero,
       projeto.projlocal,
       projeto.dnum
FROM empresaschema.projeto
WHERE (projeto.projnumero > 10);

alter table vprojeto5
    owner to postgres;

